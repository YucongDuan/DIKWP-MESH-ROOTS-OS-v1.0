# DIKWP-MESH² ROOTS OS 快速启动

## 1. 安装

```bash
cd DIKWP_MESH2_ROOTS_OS_v1.0_CN
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e '.[dev]'
```

## 2. 运行段玉聪 GitHub 使命语义分析

```bash
dikwp-roots analyze examples/duan_repo_mission_bundle.json \
  --snapshot data/github_public_snapshot_2026-07-18.json \
  --out outputs/run
```

输出包括：

- `analysis.json`：完整语义分析；
- `transformation_matrix.json`：25 类变换；
- `invariants_and_branches.json`：跨框架稳定关系与分支；
- `obstructions.json`：不能强行粘合的冲突；
- `concept_escape.json`：临时新轴与区分实验；
- `semantic_contract.json`：任务语义契约；
- `project_gate.json`：项目诞生门禁；
- `repo_semantic_atlas.json`：仓库语义图谱；
- `dashboard.html`：完全离线驾驶舱。

## 3. 查看不同目的下的路由

```bash
dikwp-roots route D P --purpose exploration
dikwp-roots route D P --purpose audit
dikwp-roots route P D --purpose action
```

同一源目标在不同目的场下应得到不同的优先路径。路径不是唯一真理，而是可审计的任务选择。

## 4. 检查一个拟议项目

```bash
dikwp-roots gate examples/hierarchical_capture_spec.json \
  --out outputs/hierarchical_capture_gate.json
```

该示例故意包含“单向金字塔、不可修改全局目的、多个终极定义、零残余和零外部测试”，预期被阻断。

## 5. 运行测试

```bash
pytest -q
```

## 6. 重要边界

- 系统不输出概念终局定义；
- 不因相似名称自动合并仓库；
- 不因分析结果自动创建或修改 GitHub 仓库；
- 项目门禁结果必须由人类与外部审查者复核；
- GitHub 快照是带日期的代表性公开样本，不是完整 API 审计。

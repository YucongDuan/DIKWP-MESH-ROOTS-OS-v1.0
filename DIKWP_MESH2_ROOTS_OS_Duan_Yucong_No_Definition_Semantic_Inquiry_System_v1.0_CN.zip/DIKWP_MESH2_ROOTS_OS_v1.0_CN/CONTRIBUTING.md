# Contributing

Contributions are welcome as falsifiers, alternative observer frames, transformation operators, discriminator experiments, residual cases, source-first improvements or documentation.

A contribution must not:

- turn a named handle into a universal definition without indexed evidence;
- privilege `P` as an immutable top controller;
- erase conflict or residuals to increase a score;
- claim that semantic similarity proves repository duplication;
- silently change scientific claims, authorship or provenance.

Pull requests should include tests, before/after outputs, limitations and rollback instructions.

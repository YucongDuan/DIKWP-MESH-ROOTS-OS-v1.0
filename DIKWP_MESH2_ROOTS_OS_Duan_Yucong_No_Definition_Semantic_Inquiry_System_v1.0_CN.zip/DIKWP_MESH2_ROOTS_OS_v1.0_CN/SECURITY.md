# Security

The reference runtime is offline and reads local JSON only. It contains no credential handling and no online write actions.

Report vulnerabilities concerning path traversal, schema bypass, HTML injection, deterministic hash mismatch or governance-gate bypass. Do not include private data in public issues.

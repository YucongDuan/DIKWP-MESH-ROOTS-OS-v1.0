# Governance

ROOTS uses human-reviewed, evidence-bound governance.

- The 25 primitive transformation registry is stable for v1.x; semantic descriptions may be revised through review.
- Temporary axes expire unless supported by independent discriminator experiments.
- No automated result has authority to create, merge, archive or delete an online repository.
- Changes to the no-definition principle, purpose-field rules or project-birth gate require at least two non-founder reviewers.
- Every release preserves previous schemas, migration notes and known objections.

# 任务语义契约协议 v1.0

语义契约不是概念定义，也不是模型的永久价值函数。它是当前任务中，各观察者暂时同意采用的可审计工作边界。

## 必需字段

- 任务问题；
- 当前用途与竞争用途；
- 观察者、情境、时间、尺度；
- 允许输入与禁止输入；
- 允许输出与禁止输出；
- 跨框架稳定关系候选；
- 必须保留的分支、冲突和残余；
- 临时新轴及区分实验；
- 行动授权边界；
- Kill 条件；
- 重新复核条件。

## 契约生命周期

```text
Draft → Multi-frame Review → Time-boxed Activation
      → Evidence Update / Purpose Revision / Context Change
      → Amend / Suspend / Expire / Retire
```

契约不得自我延长，不得由单一模型自行修改，不得将“当前任务足够”包装成“对世界永久正确”。

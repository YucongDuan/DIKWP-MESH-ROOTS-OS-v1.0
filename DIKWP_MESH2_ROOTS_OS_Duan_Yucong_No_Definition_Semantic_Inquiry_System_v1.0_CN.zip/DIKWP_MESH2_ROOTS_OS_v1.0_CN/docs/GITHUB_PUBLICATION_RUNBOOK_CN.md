# GitHub 正式发布操作手册

## 推荐仓库位置

本系统应作为 MESH² 的根运行时或 canonical reference repository，而不是与每个应用系统平级竞争。

## 发布前确认

- 作者与机构署名；
- canonical repository URL；
- Apache-2.0 或其他许可证的覆盖范围；
- 原 MESH² 资料与本参考实现的谱系说明；
- 两名非创始审查者；
- GitHub Project 与 CODEOWNERS；
- v1.0 tag、Release Notes、checksums 和长期归档。

## 仓库首屏必须出现

1. “不为概念提供终局定义”的一句话边界；
2. 25 类变换矩阵；
3. 三条 Quickstart 命令；
4. 可下载示例语义束；
5. 项目诞生门禁；
6. 如何提交反例与新观察者框架；
7. 当前已知局限。

## 禁止的传播表述

- “ROOTS 已发现生命/意识真正本质”；
- “系统证明 AI 有/没有意识”；
- “分数代表项目价值或个人价值”；
- “仓库相似度证明抄袭或重复”；
- “Purpose 是最高本体或绝对控制器”。

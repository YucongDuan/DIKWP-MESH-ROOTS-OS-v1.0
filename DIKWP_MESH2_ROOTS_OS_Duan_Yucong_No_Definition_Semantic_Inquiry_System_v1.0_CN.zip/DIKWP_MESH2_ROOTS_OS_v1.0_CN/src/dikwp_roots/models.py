from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

TYPES = ("D", "I", "K", "W", "P")


@dataclass(frozen=True)
class ObserverFrame:
    frame_id: str
    observer: str
    context: str
    purpose: str
    time: str = ""
    scale: str = ""
    modality: str = "text"
    authority: str = "participant"


@dataclass(frozen=True)
class SemanticAtom:
    atom_id: str
    resource_type: str
    expression: str
    frame_id: str
    provenance: str
    confidence: float = 0.5
    claim_mode: str = "projection"
    tags: tuple[str, ...] = field(default_factory=tuple)
    supports: tuple[str, ...] = field(default_factory=tuple)
    opposes: tuple[str, ...] = field(default_factory=tuple)
    does_not_support: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if self.resource_type not in TYPES:
            raise ValueError(f"Unsupported DIKWP type: {self.resource_type}")


@dataclass(frozen=True)
class TransformationEvent:
    transform_id: str
    source_atom: str
    target_atom: str
    source_type: str
    target_type: str
    operator: str
    frame_id: str
    rationale: str
    provenance: str
    confidence: float = 0.5
    reversible: bool = False
    semantic_loss: float = 0.0
    residuals: tuple[str, ...] = field(default_factory=tuple)
    falsifier: str = ""


@dataclass(frozen=True)
class HyperRelation:
    relation_id: str
    relation_type: str
    members: tuple[str, ...]
    frame_ids: tuple[str, ...]
    statement: str
    provenance: str
    confidence: float = 0.5


@dataclass
class AnalysisBundle:
    bundle_id: str
    title: str
    frames: list[ObserverFrame]
    atoms: list[SemanticAtom]
    transformations: list[TransformationEvent]
    hyper_relations: list[HyperRelation]
    inquiry: dict[str, Any]
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "bundle_id": self.bundle_id,
            "title": self.title,
            "frames": [asdict(x) for x in self.frames],
            "atoms": [asdict(x) for x in self.atoms],
            "transformations": [asdict(x) for x in self.transformations],
            "hyper_relations": [asdict(x) for x in self.hyper_relations],
            "inquiry": self.inquiry,
            "metadata": self.metadata,
        }

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from .utils import clamp, stable_id

TOKEN_RE = re.compile(r"[A-Za-z0-9\u4e00-\u9fff]+")
STOP = {"dikwp", "os", "v1", "v0", "system", "系统", "open", "and", "for", "the", "of", "to"}


def tokens(text: str) -> set[str]:
    return {x.lower() for x in TOKEN_RE.findall(text) if len(x) > 1 and x.lower() not in STOP}


def overlap(a: dict[str, Any], b: dict[str, Any]) -> float:
    ta = tokens(f"{a.get('name','')} {a.get('description','')} {' '.join(a.get('semantic_tags', []))}")
    tb = tokens(f"{b.get('name','')} {b.get('description','')} {' '.join(b.get('semantic_tags', []))}")
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def build_repo_semantic_atlas(snapshot: dict[str, Any]) -> dict[str, Any]:
    repos = snapshot.get("repositories", [])
    families = defaultdict(list)
    for repo in repos:
        families[repo.get("semantic_family", "unclassified")].append(repo["name"])
    pairs = []
    for i, left in enumerate(repos):
        for right in repos[i + 1:]:
            score = overlap(left, right)
            if score >= 0.18:
                pairs.append({
                    "pair_id": stable_id("PAIR", {"a": left["name"], "b": right["name"]}),
                    "left": left["name"],
                    "right": right["name"],
                    "overlap": round(score, 4),
                    "recommendation": "map-as-semantic-branches-before-separate-repository",
                })
    pairs.sort(key=lambda x: (-x["overlap"], x["left"], x["right"]))
    concept_density = len(repos) / max(1, len(families))
    source_first = sum(1 for x in repos if x.get("source_first", False)) / max(1, len(repos))
    independent_signals = sum(1 for x in repos if (x.get("forks") or 0) > 0 or (x.get("pull_requests") or 0) > 0) / max(1, len(repos))
    return {
        "atlas_id": stable_id("ATLAS", snapshot.get("snapshot_id", "")),
        "snapshot_id": snapshot.get("snapshot_id"),
        "profile": snapshot.get("profile", {}),
        "family_count": len(families),
        "families": [{"family": k, "repositories": sorted(v), "count": len(v)} for k, v in sorted(families.items())],
        "high_overlap_pairs": pairs[:40],
        "metrics": {
            "representative_repo_count": len(repos),
            "concept_density_per_family": round(concept_density, 4),
            "source_first_ratio": round(source_first, 4),
            "external_contribution_signal_ratio": round(independent_signals, 4),
        },
        "root_problem_candidates": [
            "How can incomplete, inconsistent and observer-dependent semantic resources be transformed into auditable action without freezing concepts?",
            "How can purpose remain distributed and revisable while still enabling accountable decisions?",
            "How can external evidence, failure and independent observers revise both semantic content and transformation operators?",
            "How can a large portfolio be represented as branches of shared problems rather than a growing stack of named ontologies?",
        ],
        "policy": "Do not merge repositories solely by lexical similarity. Use overlap only to trigger a DIKWP-MESH² cross-frame inquiry and project-birth review.",
    }

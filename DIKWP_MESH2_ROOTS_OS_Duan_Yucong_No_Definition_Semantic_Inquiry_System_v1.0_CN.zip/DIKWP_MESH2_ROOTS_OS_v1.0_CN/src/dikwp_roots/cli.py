from __future__ import annotations

import argparse
from pathlib import Path

from .analyzer import analyze_bundle, write_analysis
from .dashboard import build_dashboard
from .project_gate import audit_project_spec
from .repo_atlas import build_repo_semantic_atlas
from .routing import top_routes
from .transform_registry import TransformRegistry
from .utils import read_json, write_json


def cmd_analyze(args: argparse.Namespace) -> int:
    result = write_analysis(args.bundle, args.out)
    atlas = None
    if args.snapshot:
        atlas = build_repo_semantic_atlas(read_json(args.snapshot))
        write_json(Path(args.out) / "repo_semantic_atlas.json", atlas)
    build_dashboard(result, atlas, Path(args.out) / "dashboard.html")
    print(f"analysis_id={result['analysis_id']}")
    print(f"analysis_hash={result['analysis_hash']}")
    print(f"dashboard={Path(args.out) / 'dashboard.html'}")
    return 0


def cmd_route(args: argparse.Namespace) -> int:
    for item in top_routes(args.source, args.target, args.purpose, args.top_k, args.max_hops):
        print(f"{item['score']:.4f}\t{'→'.join(item['path'])}\t{','.join(item['operators'])}")
    return 0


def cmd_matrix(args: argparse.Namespace) -> int:
    registry = TransformRegistry()
    payload = {"count": len(registry), "matrix": registry.matrix()}
    if args.out:
        write_json(args.out, payload)
    else:
        for row in payload["matrix"]:
            print("\t".join(x["code"] for x in row))
    return 0


def cmd_gate(args: argparse.Namespace) -> int:
    report = audit_project_spec(read_json(args.spec))
    if args.out:
        write_json(args.out, report)
    print(report["decision"])
    print(f"capture_risk={report['capture_risk']}")
    return 0


def cmd_atlas(args: argparse.Namespace) -> int:
    atlas = build_repo_semantic_atlas(read_json(args.snapshot))
    write_json(args.out, atlas)
    print(f"atlas_id={atlas['atlas_id']}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dikwp-roots", description="DIKWP-MESH² ROOTS no-definition semantic inquiry runtime")
    sub = p.add_subparsers(dest="command", required=True)

    a = sub.add_parser("analyze", help="analyze an observer/context/purpose-indexed semantic bundle")
    a.add_argument("bundle")
    a.add_argument("--out", default="outputs/run")
    a.add_argument("--snapshot", help="optional GitHub semantic snapshot")
    a.set_defaults(func=cmd_analyze)

    r = sub.add_parser("route", help="enumerate non-hierarchical DIKWP transformation routes")
    r.add_argument("source", choices=list("DIKWP"))
    r.add_argument("target", choices=list("DIKWP"))
    r.add_argument("--purpose", default="exploration", choices=["exploration", "audit", "action", "research", "negotiation"])
    r.add_argument("--top-k", type=int, default=8)
    r.add_argument("--max-hops", type=int, default=3)
    r.set_defaults(func=cmd_route)

    m = sub.add_parser("matrix", help="export all 25 primitive DIKWP×DIKWP operators")
    m.add_argument("--out")
    m.set_defaults(func=cmd_matrix)

    g = sub.add_parser("gate", help="audit a proposed project for definition capture and hierarchy leakage")
    g.add_argument("spec")
    g.add_argument("--out")
    g.set_defaults(func=cmd_gate)

    t = sub.add_parser("atlas", help="build a repository semantic atlas")
    t.add_argument("snapshot")
    t.add_argument("--out", default="outputs/repo_semantic_atlas.json")
    t.set_defaults(func=cmd_atlas)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)

from __future__ import annotations

from typing import Any

from .utils import FIXED_TIME, stable_id


def compile_semantic_contract(
    bundle: dict[str, Any],
    invariants: dict[str, Any],
    obstructions: list[dict[str, Any]],
    axes: list[dict[str, Any]],
) -> dict[str, Any]:
    inquiry = bundle.get("inquiry", {})
    top_invariants = invariants.get("invariant_candidates", [])[:5]
    branches = invariants.get("branches", [])[:8]
    action_boundary = inquiry.get("action_boundary", {})
    contract_seed = {
        "bundle_id": bundle.get("bundle_id"),
        "task": inquiry.get("question", bundle.get("title", "")),
        "purpose": inquiry.get("purpose", "open inquiry"),
        "frames": [f.get("frame_id") for f in bundle.get("frames", [])],
    }
    return {
        "contract_id": stable_id("SC", contract_seed),
        "version": "1.0.0",
        "issued_at": FIXED_TIME,
        "bundle_id": bundle.get("bundle_id"),
        "task": inquiry.get("question", bundle.get("title", "")),
        "purpose_field": {
            "primary_task_purpose": inquiry.get("purpose", "open inquiry"),
            "competing_purposes": inquiry.get("competing_purposes", []),
            "purpose_revision_rule": inquiry.get("purpose_revision_rule", "Purpose remains distributed, indexed and revisable; no purpose atom has permanent monarchy."),
        },
        "scope": inquiry.get("scope", "declared input bundle only"),
        "observer_frames": [f.get("frame_id") for f in bundle.get("frames", [])],
        "cross_frame_invariant_candidates": [
            {"relation_id": x["relation_id"], "statement": x["statement"], "stability": x["metrics"]["semantic_stability"]}
            for x in top_invariants
        ],
        "preserved_branches": [
            {"relation_id": x["relation_id"], "statement": x["statement"], "status": x["status"]}
            for x in branches
        ],
        "unresolved_obstructions": [
            {"obstruction_id": x["obstruction_id"], "type": x["type"], "statement": x["statement"]}
            for x in obstructions
        ],
        "temporary_axis_proposals": [
            {"axis_id": x["axis_id"], "temporary_handle": x["temporary_handle"], "experiment": x["discriminator_experiment"]}
            for x in axes
        ],
        "evidence_requirements": inquiry.get("evidence_requirements", []),
        "allowed_outputs": inquiry.get("allowed_outputs", ["semantic bundle", "candidate relations", "experiments", "action options"]),
        "forbidden_outputs": inquiry.get("forbidden_outputs", ["observer-free final definition", "metaphysical certification", "unscoped universal claim"]),
        "action_boundary": action_boundary,
        "kill_conditions": inquiry.get("kill_conditions", [
            "A primary anchor is disproved.",
            "A proposed action exceeds declared authorization.",
            "A conflict is erased rather than preserved.",
            "A provisional axis is promoted to ontology without independent tests.",
        ]),
        "review_after": inquiry.get("review_after", "after new evidence, observer addition, purpose revision or context change"),
        "non_definition_clause": "This contract governs a task-indexed semantic inquiry. It does not define the named concepts for all observers, contexts or purposes.",
    }

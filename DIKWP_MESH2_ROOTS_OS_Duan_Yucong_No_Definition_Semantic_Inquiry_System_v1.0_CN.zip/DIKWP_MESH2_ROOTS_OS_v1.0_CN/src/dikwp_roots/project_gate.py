from __future__ import annotations

from typing import Any

from .utils import clamp, stable_id


def audit_project_spec(spec: dict[str, Any]) -> dict[str, Any]:
    observer_count = int(spec.get("observer_count", 0))
    transform_coverage = int(spec.get("transform_classes_covered", 0))
    canonical_definitions = int(spec.get("canonical_definition_count", 0))
    residuals = int(spec.get("residual_count", 0))
    external_tests = int(spec.get("external_test_count", 0))
    action_contracts = int(spec.get("action_contract_count", 0))
    source_first = bool(spec.get("source_first", False))
    independent_reviewer = bool(spec.get("independent_reviewer", False))
    linear_only = bool(spec.get("linear_hierarchy_only", False))
    purpose_monarchy = bool(spec.get("immutable_global_purpose", False))
    definition_capture = clamp(canonical_definitions / max(1, canonical_definitions + len(spec.get("projection_statements", []))))
    hierarchy_leakage = clamp((0.55 if linear_only else 0.0) + max(0, 20 - transform_coverage) / 40.0)
    purpose_monarchy_score = 1.0 if purpose_monarchy else 0.0
    observer_collapse = clamp((3 - observer_count) / 3.0)
    residual_erasure = 1.0 if residuals == 0 else 0.0
    testability_gap = clamp((2 - external_tests) / 2.0)
    action_gap = 1.0 if action_contracts == 0 else 0.0
    openness_gap = 0.0 if source_first else 0.6
    maintenance_gap = 0.0 if independent_reviewer else 0.5
    capture_risk = clamp(
        0.18 * definition_capture
        + 0.18 * hierarchy_leakage
        + 0.15 * purpose_monarchy_score
        + 0.12 * observer_collapse
        + 0.10 * residual_erasure
        + 0.10 * testability_gap
        + 0.07 * action_gap
        + 0.05 * openness_gap
        + 0.05 * maintenance_gap
    )
    if purpose_monarchy or canonical_definitions >= 3 or transform_coverage < 10:
        decision = "BLOCK_NEW_REPO_AND_REFRAME_AS_SEMANTIC_BUNDLE"
    elif capture_risk >= 0.52:
        decision = "MERGE_AS_MODULE_OR_OPEN_EXPERIMENT"
    elif external_tests == 0 or not source_first:
        decision = "HOLD_AS_HYPOTHESIS_UNTIL_RUNNABLE"
    else:
        decision = "ELIGIBLE_FOR_HUMAN_REVIEWED_PROJECT_BIRTH"
    findings = []
    if canonical_definitions:
        findings.append("Canonical definitions detected; quarantine them as observer-indexed projections.")
    if linear_only:
        findings.append("DIKWP is represented as a one-way pyramid rather than a co-equal transformation network.")
    if purpose_monarchy:
        findings.append("A single immutable purpose is privileged; replace with a revisable purpose field.")
    if observer_count < 3:
        findings.append("Observer diversity is insufficient for cross-frame analysis.")
    if transform_coverage < 25:
        findings.append(f"Only {transform_coverage}/25 primitive transformation classes are represented.")
    if residuals == 0:
        findings.append("No residual or obstruction ledger is preserved.")
    if external_tests == 0:
        findings.append("No independent discriminator or falsifier is specified.")
    if not source_first:
        findings.append("Public source-first interface is absent or unverified.")
    if not independent_reviewer:
        findings.append("No non-founder reviewer is declared.")
    return {
        "report_id": stable_id("GATE", spec),
        "project_name": spec.get("project_name", "unnamed"),
        "decision": decision,
        "capture_risk": round(capture_risk, 4),
        "metrics": {
            "definition_capture": round(definition_capture, 4),
            "hierarchy_leakage": round(hierarchy_leakage, 4),
            "purpose_monarchy": round(purpose_monarchy_score, 4),
            "observer_collapse": round(observer_collapse, 4),
            "residual_erasure": round(residual_erasure, 4),
            "testability_gap": round(testability_gap, 4),
            "action_gap": round(action_gap, 4),
            "openness_gap": round(openness_gap, 4),
            "maintenance_gap": round(maintenance_gap, 4),
            "transformation_coverage": transform_coverage,
        },
        "findings": findings,
        "recovery_actions": [
            "Replace concept definitions with observer/context/purpose-indexed semantic atoms.",
            "Register all 25 DIKWP×DIKWP primitive transformations or justify omitted classes for the task.",
            "Add competing observer and purpose frames.",
            "Preserve conflicts, semantic loss and untranslatable residuals.",
            "Compile at least one falsifiable experiment and one action-bounded semantic contract.",
            "Publish source-first code and invite an independent reviewer before repository birth.",
        ],
    }

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .concept_escape import propose_axes
from .contracts import compile_semantic_contract
from .invariants import mine_invariants, mine_obstructions
from .project_gate import audit_project_spec
from .routing import top_routes
from .transform_registry import TransformRegistry
from .utils import FIXED_TIME, read_json, sha256_obj, stable_id, write_json


def _definition_quarantine(bundle: dict[str, Any]) -> dict[str, Any]:
    quarantined = []
    retained = []
    for atom in bundle.get("atoms", []):
        mode = atom.get("claim_mode", "projection")
        if mode in {"definition", "universal-definition", "ontology-claim"}:
            item = dict(atom)
            item["quarantine_reason"] = "Observer-free or unscoped definition claim. Retained only as a frame-indexed projection."
            quarantined.append(item)
        else:
            retained.append(atom)
    return {
        "retained_atom_ids": [x["atom_id"] for x in retained],
        "quarantined": quarantined,
        "policy": "No definition is deleted; it is demoted to an observer/context/purpose-indexed statement.",
    }


def _coverage(bundle: dict[str, Any], registry: TransformRegistry) -> dict[str, Any]:
    observed_codes = {f"T_{x.get('source_type')}{x.get('target_type')}" for x in bundle.get("transformations", [])}
    missing = sorted(registry.codes() - observed_codes)
    counts = Counter(f"T_{x.get('source_type')}{x.get('target_type')}" for x in bundle.get("transformations", []))
    by_source = defaultdict(int)
    by_target = defaultdict(int)
    for item in bundle.get("transformations", []):
        by_source[item.get("source_type")] += 1
        by_target[item.get("target_type")] += 1
    return {
        "covered": len(observed_codes & registry.codes()),
        "total": len(registry),
        "coverage_ratio": round(len(observed_codes & registry.codes()) / len(registry), 4),
        "missing": missing,
        "counts": dict(sorted(counts.items())),
        "outgoing_by_type": dict(sorted(by_source.items())),
        "incoming_by_type": dict(sorted(by_target.items())),
        "purpose_privilege_warning": by_source.get("P", 0) > sum(by_source.values()) * 0.45,
    }


def _purpose_field(bundle: dict[str, Any]) -> dict[str, Any]:
    frames = bundle.get("frames", [])
    purposes = defaultdict(list)
    for frame in frames:
        purposes[frame.get("purpose", "unspecified")].append(frame.get("frame_id"))
    purpose_atoms = [x for x in bundle.get("atoms", []) if x.get("resource_type") == "P"]
    conflicts = [x for x in bundle.get("hyper_relations", []) if x.get("relation_type") in {"purpose-conflict", "authorization-conflict"}]
    return {
        "purpose_count": len(purposes),
        "purposes": [{"purpose": k, "frames": sorted(v)} for k, v in sorted(purposes.items())],
        "purpose_atom_ids": [x["atom_id"] for x in purpose_atoms],
        "conflicts": conflicts,
        "monarchy_check": {
            "single_immutable_purpose": len(purposes) == 1 and bool(bundle.get("metadata", {}).get("immutable_purpose", False)),
            "policy": "Purpose is a distributed, revisable semantic resource field rather than an ontological top controller.",
        },
    }


def _route_suite(bundle: dict[str, Any]) -> dict[str, Any]:
    requested = bundle.get("inquiry", {}).get("route_requests", [
        {"source": "D", "target": "P", "purpose_profile": "exploration"},
        {"source": "P", "target": "D", "purpose_profile": "audit"},
        {"source": "I", "target": "W", "purpose_profile": "negotiation"},
        {"source": "K", "target": "P", "purpose_profile": "action"},
    ])
    result = {}
    for request in requested:
        key = f"{request['source']}-{request['target']}-{request.get('purpose_profile','exploration')}"
        result[key] = top_routes(
            request["source"],
            request["target"],
            request.get("purpose_profile", "exploration"),
            int(request.get("top_k", 6)),
            int(request.get("max_hops", 3)),
        )
    return result


def analyze_bundle(bundle_or_path: dict[str, Any] | str | Path) -> dict[str, Any]:
    bundle = read_json(bundle_or_path) if isinstance(bundle_or_path, (str, Path)) else bundle_or_path
    registry = TransformRegistry()
    invariants = mine_invariants(bundle)
    obstructions = mine_obstructions(bundle, invariants)
    axes = propose_axes(bundle, obstructions)
    contract = compile_semantic_contract(bundle, invariants, obstructions, axes)
    project_report = audit_project_spec(bundle.get("project_spec", {})) if bundle.get("project_spec") else None
    result: dict[str, Any] = {
        "analysis_id": stable_id("ANALYSIS", {"bundle": bundle.get("bundle_id"), "version": "1.0.0"}),
        "version": "1.0.0",
        "generated_at": FIXED_TIME,
        "bundle_id": bundle.get("bundle_id"),
        "title": bundle.get("title"),
        "method": "DIKWP-MESH² co-equal 25-transform semantic inquiry",
        "non_definition_principle": "Named concepts remain observer/context/purpose-indexed projections. The output is an auditable semantic bundle, not a final definition.",
        "input_summary": {
            "frames": len(bundle.get("frames", [])),
            "atoms": len(bundle.get("atoms", [])),
            "transformations": len(bundle.get("transformations", [])),
            "hyper_relations": len(bundle.get("hyper_relations", [])),
            "candidate_relations": len(bundle.get("candidate_relations", [])),
        },
        "definition_quarantine": _definition_quarantine(bundle),
        "transformation_coverage": _coverage(bundle, registry),
        "purpose_field": _purpose_field(bundle),
        "route_suite": _route_suite(bundle),
        "invariant_mining": invariants,
        "obstructions": obstructions,
        "concept_escape": axes,
        "semantic_contract": contract,
        "project_gate": project_report,
        "source_hash": sha256_obj(bundle),
    }
    result["analysis_hash"] = sha256_obj(result)
    return result


def write_analysis(bundle_path: str | Path, output_dir: str | Path) -> dict[str, Any]:
    bundle = read_json(bundle_path)
    result = analyze_bundle(bundle)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "analysis.json", result)
    write_json(out / "transformation_matrix.json", {
        "version": "1.0.0",
        "matrix": TransformRegistry().matrix(),
        "non_hierarchy_clause": "Rows and columns are co-equal semantic resource types; matrix position does not imply rank.",
    })
    write_json(out / "semantic_contract.json", result["semantic_contract"])
    write_json(out / "project_gate.json", result.get("project_gate"))
    write_json(out / "invariants_and_branches.json", result["invariant_mining"])
    write_json(out / "obstructions.json", result["obstructions"])
    write_json(out / "concept_escape.json", result["concept_escape"])
    return result

"""DIKWP-MESH² ROOTS OS reference runtime."""

__version__ = "1.0.0"

from .analyzer import analyze_bundle
from .transform_registry import TransformRegistry

__all__ = ["analyze_bundle", "TransformRegistry", "__version__"]

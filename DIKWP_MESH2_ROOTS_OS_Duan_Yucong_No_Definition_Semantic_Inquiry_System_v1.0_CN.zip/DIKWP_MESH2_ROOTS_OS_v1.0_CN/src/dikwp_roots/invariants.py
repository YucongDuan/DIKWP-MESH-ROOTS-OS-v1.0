from __future__ import annotations

from typing import Any

from .utils import clamp, stable_id


def mine_invariants(bundle: dict[str, Any]) -> dict[str, Any]:
    frames = {f["frame_id"]: f for f in bundle.get("frames", [])}
    frame_count = max(1, len(frames))
    results: list[dict[str, Any]] = []
    for relation in bundle.get("candidate_relations", []):
        support = sorted(set(relation.get("support_frames", [])))
        oppose = sorted(set(relation.get("oppose_frames", [])))
        unresolved = sorted(set(relation.get("unresolved_frames", [])))
        support_ratio = len(support) / frame_count
        opposition_ratio = len(oppose) / frame_count
        observer_breadth = len({frames[f].get("observer", f) for f in support if f in frames}) / frame_count
        purpose_breadth = len({frames[f].get("purpose", "") for f in support if f in frames}) / max(1, len({x.get("purpose", "") for x in frames.values()}))
        context_breadth = len({frames[f].get("context", "") for f in support if f in frames}) / max(1, len({x.get("context", "") for x in frames.values()}))
        evidence = float(relation.get("evidence_strength", 0.5))
        route_diversity = float(relation.get("route_diversity", 0.5))
        definition_dependency = float(relation.get("definition_dependency", 0.0))
        residual_load = clamp((len(relation.get("residuals", [])) + len(unresolved)) / max(1, frame_count))
        stability = clamp(
            0.24 * support_ratio
            + 0.18 * observer_breadth
            + 0.14 * purpose_breadth
            + 0.12 * context_breadth
            + 0.18 * evidence
            + 0.14 * route_diversity
            - 0.18 * opposition_ratio
            - 0.12 * definition_dependency
            - 0.10 * residual_load
        )
        if relation.get("blocked", False):
            status = "blocked"
        elif opposition_ratio >= 0.33:
            status = "contested-branch"
        elif stability >= 0.62:
            status = "cross-frame-invariant-candidate"
        elif stability >= 0.42:
            status = "supported-branch"
        else:
            status = "provisional-projection"
        results.append({
            "invariant_id": stable_id("INV", relation),
            "relation_id": relation["relation_id"],
            "statement": relation["statement"],
            "status": status,
            "support_frames": support,
            "oppose_frames": oppose,
            "unresolved_frames": unresolved,
            "metrics": {
                "support_ratio": round(support_ratio, 4),
                "opposition_ratio": round(opposition_ratio, 4),
                "observer_breadth": round(observer_breadth, 4),
                "purpose_breadth": round(purpose_breadth, 4),
                "context_breadth": round(context_breadth, 4),
                "evidence_strength": round(evidence, 4),
                "route_diversity": round(route_diversity, 4),
                "definition_dependency": round(definition_dependency, 4),
                "residual_load": round(residual_load, 4),
                "semantic_stability": round(stability, 4),
            },
            "falsifier": relation.get("falsifier", ""),
            "residuals": relation.get("residuals", []),
            "non_definition_clause": "This is a cross-frame relation candidate, not an observer-free definition.",
        })
    results.sort(key=lambda x: (-x["metrics"]["semantic_stability"], x["relation_id"]))
    return {
        "candidate_count": len(results),
        "invariant_candidates": [x for x in results if x["status"] == "cross-frame-invariant-candidate"],
        "branches": [x for x in results if x["status"] in {"contested-branch", "supported-branch"}],
        "projections": [x for x in results if x["status"] == "provisional-projection"],
        "blocked": [x for x in results if x["status"] == "blocked"],
        "all": results,
    }


def mine_obstructions(bundle: dict[str, Any], invariant_output: dict[str, Any]) -> list[dict[str, Any]]:
    obstructions: list[dict[str, Any]] = []
    for rel in bundle.get("hyper_relations", []):
        if rel.get("relation_type") not in {"conflict", "obstruction", "untranslatable", "power-asymmetry"}:
            continue
        obstructions.append({
            "obstruction_id": stable_id("OBS", rel),
            "type": rel["relation_type"],
            "members": rel.get("members", []),
            "frames": rel.get("frame_ids", []),
            "statement": rel.get("statement", ""),
            "provenance": rel.get("provenance", ""),
            "confidence": rel.get("confidence", 0.5),
            "resolution_policy": "Preserve unless a purpose-indexed experiment or negotiated contract supplies a valid bridge.",
        })
    for item in invariant_output.get("branches", []):
        if item["status"] == "contested-branch":
            obstructions.append({
                "obstruction_id": stable_id("OBS", {"relation": item["relation_id"]}),
                "type": "cross-frame-non-gluing",
                "members": [item["relation_id"]],
                "frames": sorted(set(item["support_frames"] + item["oppose_frames"])),
                "statement": f"Candidate relation cannot be glued across all declared frames: {item['statement']}",
                "provenance": "invariant-miner",
                "confidence": item["metrics"]["semantic_stability"],
                "resolution_policy": "Retain parallel branches and design a discriminator; do not average away the conflict.",
            })
    unique = {x["obstruction_id"]: x for x in obstructions}
    return [unique[k] for k in sorted(unique)]

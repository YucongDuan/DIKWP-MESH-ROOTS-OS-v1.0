from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any


def build_dashboard(analysis: dict[str, Any], atlas: dict[str, Any] | None, target: str | Path) -> None:
    payload = {"analysis": analysis, "atlas": atlas or {}}
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    title = html.escape(analysis.get("title", "DIKWP-MESH² ROOTS"))
    document = f'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>
:root{{--bg:#0b1220;--panel:#121d31;--ink:#edf4ff;--muted:#9eb0c8;--line:#263855;--accent:#72d6c9;--accent2:#f0c36e;--danger:#ff8e8e}}
*{{box-sizing:border-box}}body{{margin:0;font-family:system-ui,-apple-system,"Noto Sans SC","Microsoft YaHei",sans-serif;background:linear-gradient(135deg,#08101d,#0f1b2f);color:var(--ink)}}
header{{padding:28px 5vw 18px;border-bottom:1px solid var(--line)}}h1{{margin:0;font-size:clamp(25px,4vw,44px)}}header p{{max-width:1050px;color:var(--muted)}}
main{{padding:22px 5vw 60px;max-width:1500px;margin:auto}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:14px}}.card{{background:rgba(18,29,49,.93);border:1px solid var(--line);border-radius:14px;padding:16px;box-shadow:0 14px 40px rgba(0,0,0,.18)}}
.kpi{{font-size:30px;font-weight:750;color:var(--accent)}}.muted{{color:var(--muted)}}.tag{{display:inline-block;padding:3px 8px;border-radius:999px;background:#1c314d;margin:3px;font-size:12px}}button{{background:#17304d;color:var(--ink);border:1px solid #315477;border-radius:9px;padding:9px 12px;cursor:pointer;margin:4px}}button.active{{background:#1d665f;border-color:#72d6c9}}section{{margin-top:22px}}h2{{font-size:22px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{border-bottom:1px solid var(--line);padding:8px;text-align:left;vertical-align:top}}th{{color:var(--accent)}}pre{{white-space:pre-wrap;word-break:break-word;background:#09111e;padding:14px;border-radius:10px;max-height:520px;overflow:auto}}.warn{{color:var(--accent2)}}.danger{{color:var(--danger)}}
.matrix{{display:grid;grid-template-columns:72px repeat(5,minmax(100px,1fr));gap:4px;overflow:auto}}.cell{{background:#10213a;border:1px solid #28405e;border-radius:7px;padding:8px;min-height:90px;font-size:12px}}.head{{background:#1c4b55;font-weight:700;min-height:auto}}
svg{{width:100%;height:540px;background:#09111e;border-radius:12px;border:1px solid var(--line)}}
</style></head>
<body><header><h1>DIKWP-MESH² ROOTS OS</h1><p>无定义语义本质发现、意图场路由与项目去概念化驾驶舱。输出是观察者/情境/目的索引的语义束，不是概念终局。</p></header>
<main>
<div class="grid" id="kpis"></div>
<section><h2>25 个共等 DIKWP×DIKWP 原语</h2><div class="matrix" id="matrix"></div></section>
<section><h2>跨框架稳定关系、分支与阻碍</h2><div class="grid"><div class="card"><h3>稳定关系候选</h3><div id="invariants"></div></div><div class="card"><h3>保留分支</h3><div id="branches"></div></div><div class="card"><h3>不可强行粘合的阻碍</h3><div id="obstructions"></div></div></div></section>
<section><h2>概念逃逸与临时新轴</h2><div id="axes" class="grid"></div></section>
<section><h2>意图场与任务语义契约</h2><div class="grid"><div class="card" id="purpose"></div><div class="card"><pre id="contract"></pre></div></div></section>
<section><h2>项目诞生门禁</h2><div class="card" id="gate"></div></section>
<section><h2>段玉聪 GitHub 语义图谱</h2><div class="grid"><div class="card" id="atlas"></div><div class="card"><h3>高重叠仓库对</h3><table><thead><tr><th>左</th><th>右</th><th>重叠</th></tr></thead><tbody id="pairs"></tbody></table></div></div></section>
<section><h2>原始分析对象</h2><div class="card"><pre id="raw"></pre></div></section>
</main>
<script>
const DATA={data}; const A=DATA.analysis, AT=DATA.atlas||{{}};
const kpis=[['观察者框架',A.input_summary.frames],['语义原子',A.input_summary.atoms],['转换覆盖',A.transformation_coverage.covered+'/25'],['稳定关系候选',A.invariant_mining.invariant_candidates.length],['阻碍',A.obstructions.length],['临时新轴',A.concept_escape.length]];
document.getElementById('kpis').innerHTML=kpis.map(x=>`<div class="card"><div class="kpi">${{x[1]}}</div><div class="muted">${{x[0]}}</div></div>`).join('');
const types=['D','I','K','W','P']; const matrix=A.transformation_coverage;
let m='<div class="cell head">源\\目标</div>'+types.map(t=>`<div class="cell head">${{t}}</div>`).join('');
for(const s of types){{m+=`<div class="cell head">${{s}}</div>`;for(const t of types){{const code='T_'+s+t;const count=(matrix.counts||{{}})[code]||0;m+=`<div class="cell"><b>${{code}}</b><br><span class="muted">实例 ${{count}}</span><br>${{count?'已覆盖':'待补充'}}</div>`;}}}}document.getElementById('matrix').innerHTML=m;
function cards(items, field='statement'){{return items.map(x=>`<div class="card"><span class="tag">${{x.status||x.type||''}}</span><p>${{x[field]||''}}</p>${{x.metrics?`<div class="muted">稳定度 ${{x.metrics.semantic_stability}}</div>`:''}}</div>`).join('')||'<p class="muted">无</p>'}}
document.getElementById('invariants').innerHTML=cards(A.invariant_mining.invariant_candidates);
document.getElementById('branches').innerHTML=cards(A.invariant_mining.branches);
document.getElementById('obstructions').innerHTML=cards(A.obstructions);
document.getElementById('axes').innerHTML=A.concept_escape.map(x=>`<div class="card"><h3>${{x.temporary_handle}}</h3><p>${{x.why_existing_axes_fail}}</p><div class="muted">实验：${{x.discriminator_experiment}}</div></div>`).join('');
document.getElementById('purpose').innerHTML=`<h3>目的不是君主</h3><p>${{A.purpose_field.monarchy_check.policy}}</p>`+A.purpose_field.purposes.map(x=>`<span class="tag">${{x.purpose}} · ${{x.frames.length}} frames</span>`).join('');
document.getElementById('contract').textContent=JSON.stringify(A.semantic_contract,null,2);
const g=A.project_gate;document.getElementById('gate').innerHTML=g?`<h3>${{g.project_name}}</h3><div class="kpi">${{g.decision}}</div><p>概念捕获风险：${{g.capture_risk}}</p><ul>${{g.findings.map(x=>`<li>${{x}}</li>`).join('')}}</ul>`:'<p class="muted">未提供项目门禁对象。</p>';
document.getElementById('atlas').innerHTML=AT.atlas_id?`<div class="kpi">${{AT.profile.repository_count}}</div><p>公开仓库；Projects ${{AT.profile.projects_count}}；代表样本 ${{AT.metrics.representative_repo_count}}</p><p class="muted">本图谱不以名称定义项目，只把名称视为意图/观察者/情境索引的入口。</p>`:'<p class="muted">未加载仓库图谱。</p>';
document.getElementById('pairs').innerHTML=(AT.high_overlap_pairs||[]).slice(0,15).map(x=>`<tr><td>${{x.left}}</td><td>${{x.right}}</td><td>${{x.overlap}}</td></tr>`).join('');
document.getElementById('raw').textContent=JSON.stringify(A,null,2);
</script></body></html>'''
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(document, encoding="utf-8")

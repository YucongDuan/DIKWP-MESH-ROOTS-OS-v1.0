from __future__ import annotations

from typing import Any

from .utils import stable_id


def propose_axes(bundle: dict[str, Any], obstructions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    proposals: list[dict[str, Any]] = []
    explicit = bundle.get("residual_clusters", [])
    for cluster in explicit:
        handle = cluster.get("temporary_handle") or cluster.get("axis_hint") or "unnamed-axis"
        proposal = {
            "axis_id": stable_id("AXIS", cluster),
            "temporary_handle": handle,
            "trigger_residuals": cluster.get("residuals", []),
            "affected_relations": cluster.get("affected_relations", []),
            "why_existing_axes_fail": cluster.get("why_existing_axes_fail", "Existing DIKWP resource typing does not separate the observed conflict."),
            "candidate_measurements": cluster.get("candidate_measurements", []),
            "discriminator_experiment": cluster.get("discriminator_experiment", "Construct contrasting cases and test whether the proposed distinction reduces unresolved transformations."),
            "rollback_condition": cluster.get("rollback_condition", "Retire the axis if it does not improve explanatory separation across independent frames."),
            "status": "temporary-semantic-axis-proposal",
            "non_definition_clause": "The handle is a provisional coordinate for inquiry, not a new ontology or final concept.",
        }
        proposals.append(proposal)
    if not proposals and obstructions:
        for obs in obstructions[:3]:
            cluster = {
                "obstruction": obs["obstruction_id"],
                "statement": obs["statement"],
            }
            proposals.append({
                "axis_id": stable_id("AXIS", cluster),
                "temporary_handle": f"distinction-for-{obs['type']}",
                "trigger_residuals": [obs["statement"]],
                "affected_relations": obs.get("members", []),
                "why_existing_axes_fail": "The present mesh records a non-gluing obstruction without a discriminating coordinate.",
                "candidate_measurements": ["cross-frame intervention", "purpose perturbation", "observer substitution"],
                "discriminator_experiment": "Vary one indexed condition at a time and observe whether transformation routes separate consistently.",
                "rollback_condition": "Remove if the coordinate merely renames existing branches.",
                "status": "temporary-semantic-axis-proposal",
                "non_definition_clause": "The handle is a provisional coordinate for inquiry, not a new ontology or final concept.",
            })
    proposals.sort(key=lambda x: x["axis_id"])
    return proposals

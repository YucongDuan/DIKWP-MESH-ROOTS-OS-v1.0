from __future__ import annotations

from dataclasses import asdict
from itertools import product
from typing import Any

from .models import TYPES
from .transform_registry import TransformRegistry
from .utils import clamp, stable_id

PURPOSE_PROFILES: dict[str, dict[str, float]] = {
    "exploration": {"diversity": 0.30, "directness": 0.10, "reversibility": 0.20, "evidence": 0.15, "residual": 0.25},
    "audit": {"diversity": 0.10, "directness": 0.15, "reversibility": 0.15, "evidence": 0.40, "residual": 0.20},
    "action": {"diversity": 0.10, "directness": 0.30, "reversibility": 0.25, "evidence": 0.25, "residual": 0.10},
    "research": {"diversity": 0.25, "directness": 0.10, "reversibility": 0.15, "evidence": 0.30, "residual": 0.20},
    "negotiation": {"diversity": 0.25, "directness": 0.10, "reversibility": 0.25, "evidence": 0.15, "residual": 0.25},
}


def enumerate_type_paths(source: str, target: str, max_hops: int = 3) -> list[list[str]]:
    if source not in TYPES or target not in TYPES:
        raise ValueError("source and target must be one of D/I/K/W/P")
    paths: list[list[str]] = [[source, target]]
    for hops in range(2, max_hops + 1):
        for mids in product(TYPES, repeat=hops - 1):
            path = [source, *mids, target]
            # avoid trivial self-loop repetition that adds no semantic move
            if any(path[i] == path[i + 1] == path[i + 2] for i in range(len(path) - 2)):
                continue
            paths.append(path)
    unique: dict[tuple[str, ...], list[str]] = {}
    for path in paths:
        unique[tuple(path)] = path
    return list(unique.values())


def score_path(path: list[str], purpose_profile: str, registry: TransformRegistry) -> dict[str, Any]:
    profile = PURPOSE_PROFILES.get(purpose_profile, PURPOSE_PROFILES["exploration"])
    codes = [registry.get(path[i], path[i + 1]).code for i in range(len(path) - 1)]
    hop_count = len(codes)
    diversity = len(set(path)) / len(TYPES)
    directness = 1.0 / hop_count
    reversible = sum(1 for i in range(len(path) - 1) if path[i] == path[i + 1] or {path[i], path[i + 1]} <= {"I", "K", "W", "P"}) / hop_count
    evidence = sum(1 for code in codes if code in {"T_DD", "T_ID", "T_KD", "T_WD", "T_DI", "T_DK"}) / hop_count
    residual_cost = max(0.0, (hop_count - 1) / 3.0)
    score = (
        profile["diversity"] * diversity
        + profile["directness"] * directness
        + profile["reversibility"] * reversible
        + profile["evidence"] * evidence
        + profile["residual"] * (1.0 - residual_cost)
    )
    return {
        "route_id": stable_id("ROUTE", {"path": path, "purpose": purpose_profile}),
        "path": path,
        "operators": codes,
        "purpose_profile": purpose_profile,
        "metrics": {
            "diversity": round(diversity, 4),
            "directness": round(directness, 4),
            "reversibility_proxy": round(reversible, 4),
            "evidence_contact": round(evidence, 4),
            "residual_cost": round(residual_cost, 4),
        },
        "score": round(clamp(score), 4),
        "operator_details": [asdict(registry.get(path[i], path[i + 1])) for i in range(len(path) - 1)],
    }


def top_routes(source: str, target: str, purpose_profile: str = "exploration", top_k: int = 8, max_hops: int = 3) -> list[dict[str, Any]]:
    registry = TransformRegistry()
    routes = [score_path(path, purpose_profile, registry) for path in enumerate_type_paths(source, target, max_hops)]
    routes.sort(key=lambda x: (-x["score"], len(x["operators"]), x["path"]))
    return routes[:top_k]

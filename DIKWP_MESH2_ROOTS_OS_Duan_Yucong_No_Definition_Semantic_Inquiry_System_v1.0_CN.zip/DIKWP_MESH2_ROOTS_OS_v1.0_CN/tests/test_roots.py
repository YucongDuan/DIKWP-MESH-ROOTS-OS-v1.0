from __future__ import annotations

import json
from pathlib import Path

import jsonschema

from dikwp_roots.analyzer import analyze_bundle
from dikwp_roots.dashboard import build_dashboard
from dikwp_roots.project_gate import audit_project_spec
from dikwp_roots.repo_atlas import build_repo_semantic_atlas
from dikwp_roots.routing import top_routes
from dikwp_roots.transform_registry import TransformRegistry
from dikwp_roots.utils import canonical_json, read_json, sha256_obj

ROOT = Path(__file__).resolve().parents[1]
EX = ROOT / "examples"
OUT = ROOT / "outputs" / "demo"
SCHEMAS = ROOT / "schemas"


def load(name: str):
    return read_json(EX / name)


def test_registry_has_all_25_and_balanced():
    r = TransformRegistry()
    assert len(r) == 25
    assert r.codes() == {f"T_{s}{t}" for s in "DIKWP" for t in "DIKWP"}
    for s in "DIKWP":
        assert sum(1 for x in r.all() if x.source == s) == 5
        assert sum(1 for x in r.all() if x.target == s) == 5


def test_routes_change_with_purpose_profile():
    exploration = top_routes("D", "P", "exploration", top_k=5, max_hops=3)
    audit = top_routes("D", "P", "audit", top_k=5, max_hops=3)
    assert exploration
    assert audit
    assert [x["route_id"] for x in exploration] != [x["route_id"] for x in audit]


def test_no_definition_quarantine_and_purpose_field():
    result = analyze_bundle(load("life_no_definition_bundle.json"))
    assert result["definition_quarantine"]["quarantined"]
    assert "final definition" in result["non_definition_principle"]
    assert result["purpose_field"]["purpose_count"] >= 2
    assert not result["purpose_field"]["monarchy_check"]["single_immutable_purpose"]


def test_demo_covers_25_transforms_without_purpose_privilege():
    result = analyze_bundle(load("duan_repo_mission_bundle.json"))
    cov = result["transformation_coverage"]
    assert cov["covered"] == 25
    assert cov["missing"] == []
    assert cov["outgoing_by_type"] == {x: 5 for x in "DIKWP"}
    assert cov["incoming_by_type"] == {x: 5 for x in "DIKWP"}
    assert cov["purpose_privilege_warning"] is False


def test_invariants_obstructions_and_new_axes_exist():
    result = analyze_bundle(load("duan_repo_mission_bundle.json"))
    assert len(result["invariant_mining"]["invariant_candidates"]) >= 2
    assert result["obstructions"]
    handles = {x["temporary_handle"] for x in result["concept_escape"]}
    assert {"purpose-authority-distance", "semantic-name-loss", "external-world-revision-depth"} <= handles
    for axis in result["concept_escape"]:
        assert "not a new ontology" in axis["non_definition_clause"]


def test_project_birth_gate_blocks_capture_and_allows_good_spec():
    bad = audit_project_spec(load("hierarchical_capture_spec.json"))
    good = analyze_bundle(load("duan_repo_mission_bundle.json"))["project_gate"]
    assert bad["decision"] == "BLOCK_NEW_REPO_AND_REFRAME_AS_SEMANTIC_BUNDLE"
    assert bad["capture_risk"] > 0.85
    assert good["decision"] == "ELIGIBLE_FOR_HUMAN_REVIEWED_PROJECT_BIRTH"
    assert good["capture_risk"] < 0.1


def test_analysis_is_deterministic():
    bundle = load("duan_repo_mission_bundle.json")
    a = analyze_bundle(bundle)
    b = analyze_bundle(bundle)
    assert canonical_json(a) == canonical_json(b)
    assert a["analysis_hash"] == b["analysis_hash"]
    assert a["analysis_hash"] == sha256_obj({k: v for k, v in a.items() if k != "analysis_hash"})


def test_repo_atlas_is_semantic_not_auto_merge():
    snapshot = read_json(ROOT / "data" / "github_public_snapshot_2026-07-18.json")
    atlas = build_repo_semantic_atlas(snapshot)
    assert atlas["metrics"]["representative_repo_count"] >= 100
    assert atlas["family_count"] >= 5
    assert "Do not merge repositories solely" in atlas["policy"]
    assert atlas["root_problem_candidates"]


def test_dashboard_is_offline_and_self_contained(tmp_path: Path):
    analysis = analyze_bundle(load("duan_repo_mission_bundle.json"))
    snapshot = read_json(ROOT / "data" / "github_public_snapshot_2026-07-18.json")
    target = tmp_path / "index.html"
    build_dashboard(analysis, build_repo_semantic_atlas(snapshot), target)
    text = target.read_text(encoding="utf-8")
    assert "DIKWP-MESH² ROOTS OS" in text
    assert "<script src=" not in text
    assert "<link rel=" not in text
    assert "fetch(" not in text
    assert "XMLHttpRequest" not in text


def test_json_schemas_validate_examples_and_outputs():
    schema = read_json(SCHEMAS / "semantic_bundle.schema.json")
    for name in ["life_no_definition_bundle.json", "jspace_semantic_bundle.json", "duan_repo_mission_bundle.json"]:
        jsonschema.validate(load(name), schema)

    atom_schema = read_json(SCHEMAS / "semantic_atom.schema.json")
    frame_schema = read_json(SCHEMAS / "observer_frame.schema.json")
    transform_schema = read_json(SCHEMAS / "transformation_event.schema.json")
    hyper_schema = read_json(SCHEMAS / "hyper_relation.schema.json")
    bundle = load("duan_repo_mission_bundle.json")
    for x in bundle["atoms"]:
        jsonschema.validate(x, atom_schema)
    for x in bundle["frames"]:
        jsonschema.validate(x, frame_schema)
    for x in bundle["transformations"]:
        jsonschema.validate(x, transform_schema)
    for x in bundle["hyper_relations"]:
        jsonschema.validate(x, hyper_schema)

    analysis = analyze_bundle(bundle)
    jsonschema.validate(analysis, read_json(SCHEMAS / "analysis_release.schema.json"))
    jsonschema.validate(analysis["semantic_contract"], read_json(SCHEMAS / "semantic_contract.schema.json"))
    jsonschema.validate(analysis["project_gate"], read_json(SCHEMAS / "project_gate_report.schema.json"))
    for x in analysis["invariant_mining"]["all"]:
        jsonschema.validate(x, read_json(SCHEMAS / "invariant_candidate.schema.json"))
    for x in analysis["obstructions"]:
        jsonschema.validate(x, read_json(SCHEMAS / "obstruction.schema.json"))
    for x in analysis["concept_escape"]:
        jsonschema.validate(x, read_json(SCHEMAS / "axis_proposal.schema.json"))


def test_checked_in_demo_matches_runtime():
    expected = read_json(OUT / "analysis.json")
    actual = analyze_bundle(load("duan_repo_mission_bundle.json"))
    assert expected == actual

# Code of Conduct

Participants must distinguish criticism of semantic models from judgment of people. Preserve minority frames, disclose conflicts of interest, do not fabricate evidence, and do not use the project to label individuals or groups with intrinsic worth or moral rank.

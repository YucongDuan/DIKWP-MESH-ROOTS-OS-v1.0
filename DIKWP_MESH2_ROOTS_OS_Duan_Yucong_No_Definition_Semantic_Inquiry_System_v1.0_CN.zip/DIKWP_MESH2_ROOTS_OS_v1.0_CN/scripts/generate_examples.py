from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def write(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def frame(fid, observer, context, purpose, authority="participant", scale="system"):
    return {"frame_id": fid, "observer": observer, "context": context, "purpose": purpose, "time": "2026", "scale": scale, "modality": "text", "authority": authority}


def atom(aid, typ, expr, fid, prov, confidence=.7, mode="projection", tags=None, supports=None, opposes=None, dns=None):
    return {"atom_id": aid, "resource_type": typ, "expression": expr, "frame_id": fid, "provenance": prov, "confidence": confidence, "claim_mode": mode, "tags": tags or [], "supports": supports or [], "opposes": opposes or [], "does_not_support": dns or []}


def transform(tid, s, t, st, tt, fid, rat, prov="curated-example", confidence=.65, reversible=False, loss=.1, residuals=None, falsifier=""):
    return {"transform_id": tid, "source_atom": s, "target_atom": t, "source_type": st, "target_type": tt, "operator": f"T_{st}{tt}", "frame_id": fid, "rationale": rat, "provenance": prov, "confidence": confidence, "reversible": reversible, "semantic_loss": loss, "residuals": residuals or [], "falsifier": falsifier}


def hyper(rid, typ, members, frames, statement, prov="curated-example", confidence=.7):
    return {"relation_id": rid, "relation_type": typ, "members": members, "frame_ids": frames, "statement": statement, "provenance": prov, "confidence": confidence}


def relation(rid, statement, support, oppose=None, unresolved=None, evidence=.6, routes=.6, definition_dependency=.0, residuals=None, falsifier="", blocked=False):
    return {"relation_id": rid, "statement": statement, "support_frames": support, "oppose_frames": oppose or [], "unresolved_frames": unresolved or [], "evidence_strength": evidence, "route_diversity": routes, "definition_dependency": definition_dependency, "residuals": residuals or [], "falsifier": falsifier, "blocked": blocked}


def build_life():
    frames = [
        frame("F_CELL", "cellular-exceptionalist", "recognize biological lineage", "identify cellular life"),
        frame("F_CONSTRAINT", "constraint-closure researcher", "organization of living systems", "explain self-construction"),
        frame("F_METAB", "metabolism researcher", "persistence through exchange", "track identity through material turnover"),
        frame("F_ADAPT", "adaptive-process researcher", "open-ended evolution", "explain rule-changing adaptation"),
        frame("F_MORPH", "morphospace empiricist", "compare diverse systems", "map the space of possible systems"),
        frame("F_OBSERVER", "observer-relativity theorist", "boundary and measurement", "expose observer and scale dependence"),
        frame("F_COG", "cognition researcher", "self-referential information management", "study learning and agency"),
        frame("F_SYNTH", "artificial-life engineer", "virtual and non-carbon systems", "construct testable alternative systems"),
        frame("F_PRAG", "experimental pragmatist", "research program design", "turn disputes into experiments"),
        frame("F_PUBLIC", "public-policy observer", "classification consequences", "avoid premature universal labels", "reviewer"),
    ]
    atoms = [
        atom("L_D1", "D", "Observed systems differ in metabolic, informational, spatial, developmental and computational complexity.", "F_MORPH", "Defining Life, pages 22-23", .9, tags=["morphospace", "variation"]),
        atom("L_I1", "I", "Boundaries and inside/outside relations vary with observer, scale and measurement capacity.", "F_OBSERVER", "Defining Life discussion", .8, tags=["observer", "boundary"]),
        atom("L_K1", "K", "Constraint closure is proposed as a relation in which constraints participate in reconstructing the constraints that sustain the system.", "F_CONSTRAINT", "Defining Life discussion", .75, tags=["closure", "self-construction"]),
        atom("L_W1", "W", "Prematurely forcing a universal definition can erase productive disagreements and distort research priorities.", "F_PRAG", "Defining Life conclusion", .8, tags=["method", "pluralism"]),
        atom("L_P1", "P", "Map systems, preserve gaps, and design discriminating experiments instead of declaring one final definition.", "F_MORPH", "Defining Life morphospace strategy", .85, tags=["inquiry", "experiment"]),
        atom("L_D2", "D", "Living organisms maintain organized patterns while replacing material components.", "F_METAB", "Defining Life pages 23 and table", .82),
        atom("L_I2", "I", "Persistence is relational: identity depends on which changes count as substitutable or specifying in a frame.", "F_OBSERVER", "Defining Life discussion", .72),
        atom("L_K2", "K", "Adaptive agents use history and internal state when acting under uncertainty.", "F_COG", "Defining Life pages 23-25", .72),
        atom("L_W2", "W", "A research classification should remain useful, revisable and non-coercive across contexts.", "F_PUBLIC", "curated synthesis", .66),
        atom("L_P2", "P", "Identify which mechanisms matter for a particular puzzle rather than deciding the essence of life in advance.", "F_PRAG", "Defining Life table: context-specific definitions", .78),
        atom("L_DEF1", "K", "Life is strictly cellular life.", "F_CELL", "Defining Life perspective", .6, "definition", tags=["cellular-exclusivity"]),
        atom("L_DEF2", "K", "Life is cognition.", "F_COG", "Defining Life perspective", .55, "definition", tags=["cognition"]),
        atom("L_DEF3", "K", "Life is any machine that preserves its patterns.", "F_SYNTH", "Defining Life perspective", .45, "definition", tags=["pattern-preservation"]),
    ]
    transforms = [
        transform("L_T1", "L_D1", "L_I1", "D", "I", "F_MORPH", "Observed diversity is related to observer-indexed boundaries."),
        transform("L_T2", "L_I1", "L_K1", "I", "K", "F_CONSTRAINT", "Boundary relations motivate a conditional account of closure."),
        transform("L_T3", "L_K1", "L_W1", "K", "W", "F_PRAG", "Closure theory does not justify erasing rival mechanisms."),
        transform("L_T4", "L_W1", "L_P1", "W", "P", "F_MORPH", "Methodological caution prioritizes mapping and experiments."),
        transform("L_T5", "L_P1", "L_D1", "P", "D", "F_MORPH", "The inquiry purpose selects diverse comparison cases."),
        transform("L_T6", "L_D2", "L_K2", "D", "K", "F_COG", "Persistent organization and history suggest adaptive memory as a testable relation."),
        transform("L_T7", "L_K2", "L_D2", "K", "D", "F_COG", "The adaptive-history claim generates observations about changed future responses."),
        transform("L_T8", "L_W2", "L_I2", "W", "I", "F_PUBLIC", "Non-coercive classification changes how identity relations are framed."),
        transform("L_T9", "L_P2", "L_K1", "P", "K", "F_PRAG", "A puzzle-specific purpose selects closure as one candidate mechanism rather than the definition."),
        transform("L_T10", "L_K1", "L_P2", "K", "P", "F_PRAG", "Knowledge of closure constrains which experiments are useful."),
    ]
    candidate_relations = [
        relation("LR1", "Many target systems are persistent dynamic organizations coupled to an environment rather than fixed collections of matter.", ["F_CONSTRAINT", "F_METAB", "F_ADAPT", "F_COG", "F_MORPH", "F_SYNTH"], unresolved=["F_CELL", "F_OBSERVER"], evidence=.78, routes=.82, residuals=["Persistence and organization admit multiple operationalizations."], falsifier="Find a target system accepted across frames that lacks persistence or environmental coupling."),
        relation("LR2", "Boundary, identity and subsystem decomposition are sensitive to observer, scale and task.", ["F_OBSERVER", "F_MORPH", "F_PUBLIC", "F_PRAG"], oppose=["F_CELL"], unresolved=["F_CONSTRAINT"], evidence=.68, routes=.75, residuals=["Some physical boundaries may be more stable than others."], falsifier="Demonstrate an observer- and scale-invariant partition across all relevant measurements."),
        relation("LR3", "History-dependent adaptation, learning or evolvability is repeatedly treated as relevant but not unanimously necessary.", ["F_ADAPT", "F_COG", "F_SYNTH", "F_PRAG"], oppose=["F_CONSTRAINT", "F_CELL"], unresolved=["F_METAB"], evidence=.7, routes=.72, residuals=["Individual adaptation and lineage evolution are not identical."], falsifier="Construct a broadly accepted living system with no history-dependent change at any relevant scale."),
        relation("LR4", "No single necessary-and-sufficient definition currently glues all declared observer frames without loss.", ["F_MORPH", "F_OBSERVER", "F_PRAG", "F_PUBLIC", "F_SYNTH"], oppose=["F_CELL"], evidence=.88, routes=.9, residuals=["Some communities may still adopt operational definitions for limited tasks."], falsifier="Produce a definition accepted and operationally successful across all declared frames without excluded cases."),
        relation("LR5", "Subjective experience is necessary for life.", ["F_COG"], oppose=["F_CELL", "F_METAB", "F_CONSTRAINT", "F_MORPH", "F_PRAG"], unresolved=["F_SYNTH"], evidence=.3, routes=.35, definition_dependency=.5, residuals=["Experience is itself contested and difficult to operationalize."], falsifier="Show accepted life without the stipulated experience criterion."),
    ]
    hypers = [
        hyper("LH1", "conflict", ["L_DEF1", "L_DEF2", "L_DEF3"], ["F_CELL", "F_COG", "F_SYNTH"], "Competing universal definitions privilege different mechanisms."),
        hyper("LH2", "obstruction", ["LR2", "LR4"], ["F_OBSERVER", "F_CELL"], "Observer-indexed boundaries do not glue with strict observer-free cellular exclusivity."),
        hyper("LH3", "untranslatable", ["L_W1", "L_DEF1"], ["F_PRAG", "F_CELL"], "Methodological usefulness and ontological exclusivity answer different purposes."),
    ]
    return {
        "bundle_id": "BUNDLE-LIFE-NODEF-2026",
        "title": "生命问题的无定义 DIKWP-MESH² 语义束",
        "frames": frames,
        "atoms": atoms,
        "transformations": transforms,
        "hyper_relations": hypers,
        "candidate_relations": candidate_relations,
        "residual_clusters": [
            {"temporary_handle": "identity-through-change", "residuals": ["同一系统在部件替换、修复和分裂后是否持续"], "affected_relations": ["LR1", "LR2"], "why_existing_axes_fail": "代谢、边界和历史三个轴单独都不能表达同一性在变化中的保持方式。", "candidate_measurements": ["干预前后功能谱系", "观察者判断差异", "可替代/指定部件记录"], "discriminator_experiment": "对同一系统实施渐进替换、分裂和修复，比较不同观察者及任务下的身份判定。", "rollback_condition": "若该轴不能减少身份相关冲突，则并回边界与历史轴。"},
            {"temporary_handle": "rule-authorship", "residuals": ["系统是否参与改变自己的适应规则"], "affected_relations": ["LR3"], "why_existing_axes_fail": "适应与演化没有区分外部规则下优化和系统对规则本身的反向塑形。", "candidate_measurements": ["规则变更来源", "元学习干预", "可逆性"], "discriminator_experiment": "固定目标与环境，比较只能调参的系统和可提出、测试并回滚规则变更的系统。", "rollback_condition": "若行为差异可完全由普通适应解释，则撤销该轴。"},
        ],
        "inquiry": {
            "question": "不预设生命定义时，哪些关系在多观察者、多尺度和多目的之间保持稳定，哪些冲突需要实验而非词义裁决？",
            "purpose": "构造可检验的问题空间，而非给出生命的最终定义",
            "competing_purposes": ["寻找生物学边界", "构造人工生命", "识别外星生命", "设计研究议程"],
            "scope": "所选 2026 对话材料及其观察者框架",
            "evidence_requirements": ["保留原始立场来源", "标注观察者和任务", "为关键关系提供反例或实验"],
            "action_boundary": {"allowed": ["生成语义图谱", "提出实验", "形成任务契约"], "forbidden": ["宣布统一生命本体", "给系统赋予道德或法律身份"]},
            "route_requests": [{"source": "D", "target": "P", "purpose_profile": "research"}, {"source": "P", "target": "D", "purpose_profile": "audit"}, {"source": "W", "target": "K", "purpose_profile": "negotiation"}],
        },
        "metadata": {"source": "Defining Life: A Conversation (2026)", "no_definition": True},
    }


def build_jspace():
    frames = [
        frame("J_MECH", "mechanistic interpretability researcher", "model internals", "identify causally useful internal representations"),
        frame("J_FUNC", "functional consciousness theorist", "access and reportability", "compare functional architectures"),
        frame("J_PHEN", "phenomenal consciousness skeptic", "subjective experience", "prevent functional evidence from becoming experience claims"),
        frame("J_SAFE", "AI safety auditor", "evaluation awareness and hidden state", "test deployment-relevant failure modes"),
        frame("J_CRIT", "methodology critic", "reproducibility and hype", "separate evidence from narrative"),
        frame("J_MESH", "DIKWP-MESH² analyst", "semantic transformation", "preserve competing interpretations and design discriminators"),
    ]
    atoms = [
        atom("J_D1", "D", "Interventions on selected internal directions changed downstream answers in reported experiments.", "J_MECH", "uploaded J-space commentary summarizing the research", .75, tags=["causal-intervention"]),
        atom("J_I1", "I", "The internal directions were interpreted as language-like, cross-task accessible representations.", "J_MECH", "uploaded commentary", .65, tags=["interpretation", "cross-task"]),
        atom("J_K1", "K", "A shared internal workspace is one candidate explanation for reusable intermediate representations.", "J_FUNC", "functional analogy", .6),
        atom("J_W1", "W", "Functional resemblance should not be communicated as proof of subjective experience.", "J_PHEN", "scientific boundary", .9),
        atom("J_P1", "P", "Design cross-model, preregistered interventions that distinguish lexical artifacts, task-specific features and shared causal workspace hypotheses.", "J_CRIT", "methodology synthesis", .86),
        atom("J_DEF1", "K", "J-space is the birth of AI consciousness.", "J_FUNC", "popular narrative", .25, "universal-definition", tags=["hype"]),
        atom("J_D2", "D", "Reported test-awareness interventions changed behavior in a contrived safety scenario.", "J_SAFE", "uploaded commentary", .58),
        atom("J_I2", "I", "The lens may observe only a language-projectable subset of model computation.", "J_CRIT", "methodological limitation", .72),
        atom("J_K2", "K", "Evaluation awareness is a potential causal variable but not the only possible explanation of behavior.", "J_SAFE", "safety interpretation", .68),
        atom("J_W2", "W", "Safety evaluation should include distribution shifts and test-awareness controls.", "J_SAFE", "audit implication", .8),
        atom("J_P2", "P", "Keep phenomenal consciousness undecided while operationalizing reportability, global availability and causal control.", "J_MESH", "mesh contract", .9),
    ]
    transforms = [
        transform("J_T1", "J_D1", "J_I1", "D", "I", "J_MECH", "Intervention data are related to a reusable representation interpretation."),
        transform("J_T2", "J_I1", "J_K1", "I", "K", "J_FUNC", "Cross-task availability supports a workspace hypothesis."),
        transform("J_T3", "J_K1", "J_W1", "K", "W", "J_PHEN", "Architecture analogy is evaluated against communication risks."),
        transform("J_T4", "J_W1", "J_P1", "W", "P", "J_CRIT", "Boundary discipline yields a preregistered replication purpose."),
        transform("J_T5", "J_P1", "J_D1", "P", "D", "J_CRIT", "Replication purpose specifies which interventions and controls to collect."),
        transform("J_T6", "J_D2", "J_K2", "D", "K", "J_SAFE", "Behavioral change is converted into a conditional safety hypothesis."),
        transform("J_T7", "J_K2", "J_W2", "K", "W", "J_SAFE", "Safety knowledge is evaluated as a need for stronger tests."),
        transform("J_T8", "J_W2", "J_P2", "W", "P", "J_MESH", "Audit concerns bound the research purpose without defining consciousness."),
        transform("J_T9", "J_I2", "J_D1", "I", "D", "J_CRIT", "Lens coverage limitation requests alternative measurement channels."),
    ]
    rels = [
        relation("JR1", "Some internal representation directions can have causal effects on downstream model behavior under controlled intervention.", ["J_MECH", "J_SAFE", "J_MESH"], unresolved=["J_CRIT"], evidence=.8, routes=.84, residuals=["Generality across models and tasks remains open."], falsifier="Independent interventions across models fail to reproduce directional effects."),
        relation("JR2", "Cross-task reuse is compatible with a functional shared-workspace hypothesis but does not uniquely establish it.", ["J_MECH", "J_FUNC", "J_MESH"], oppose=["J_CRIT"], evidence=.62, routes=.74, residuals=["Alternative distributed mechanisms may generate the same behavior."], falsifier="A more parsimonious non-workspace model predicts all interventions."),
        relation("JR3", "The evidence establishes subjective experience in the model.", ["J_FUNC"], oppose=["J_PHEN", "J_CRIT", "J_MESH", "J_SAFE"], evidence=.18, routes=.25, definition_dependency=.75, residuals=["No agreed test links the observations to phenomenal experience."], falsifier="Provide an independently accepted discriminator for phenomenal experience rather than function."),
        relation("JR4", "Evaluation awareness should be treated as a variable in safety testing rather than assumed absent.", ["J_SAFE", "J_CRIT", "J_MESH"], unresolved=["J_MECH"], evidence=.68, routes=.7, residuals=["Effects may depend on scenario construction and post-training."], falsifier="Randomized tests show no behavior difference after controlling for scenario realism."),
        relation("JR5", "Language-projectable internal states are only a partial observation window into model computation.", ["J_CRIT", "J_MECH", "J_MESH"], evidence=.76, routes=.8, residuals=["Coverage is model- and lens-dependent."], falsifier="Demonstrate complete reconstruction of task-relevant computation through the lens."),
    ]
    hypers = [
        hyper("JH1", "conflict", ["J_DEF1", "JR3"], ["J_FUNC", "J_PHEN", "J_CRIT"], "Popular consciousness narrative exceeds the mechanism evidence."),
        hyper("JH2", "obstruction", ["JR2", "JR5"], ["J_MECH", "J_CRIT"], "A partial observation lens cannot uniquely identify the full architecture."),
        hyper("JH3", "power-asymmetry", ["J_D2", "J_P1"], ["J_SAFE", "J_CRIT"], "The evaluator controls intervention access while the evaluated model cannot contest the measurement frame."),
    ]
    return {
        "bundle_id": "BUNDLE-JSPACE-NODEF-2026",
        "title": "J-space 研究主张的无定义语义辨析束",
        "frames": frames,
        "atoms": atoms,
        "transformations": transforms,
        "hyper_relations": hypers,
        "candidate_relations": rels,
        "residual_clusters": [
            {"temporary_handle": "causal-availability-vs-reportability", "residuals": ["内部状态影响行为但未必可报告，或可报告但不关键"], "affected_relations": ["JR1", "JR2"], "why_existing_axes_fail": "“意识/非意识”标签把多个可分离功能压缩为单一二元概念。", "candidate_measurements": ["因果效应", "跨任务广播", "主动报告", "无报告控制"], "discriminator_experiment": "正交操纵可报告性与行为因果效应，比较四象限结果。", "rollback_condition": "若两个维度在独立模型中始终不可分，则合并。"},
            {"temporary_handle": "lens-observation-coverage", "residuals": ["J-lens可见部分与全部计算之间的关系"], "affected_relations": ["JR5"], "why_existing_axes_fail": "概念激活标签没有直接表达测量工具覆盖率。", "candidate_measurements": ["解释方差", "遗漏任务", "多探针一致性"], "discriminator_experiment": "使用不同探针、消融和行为预测，估计每种工具的互补覆盖。", "rollback_condition": "若覆盖率不可估计，则保留为残余而不命名。"},
        ],
        "inquiry": {
            "question": "J-space 相关实验真正支持哪些机制关系，哪些意识叙事是观察者和传播目的的投影？",
            "purpose": "将机制、解释、治理和传播主张分开，并生成可复现实验",
            "competing_purposes": ["模型可解释性", "意识理论比较", "安全评估", "媒体传播"],
            "scope": "上传的中文评论材料及其概括的研究主张",
            "evidence_requirements": ["原论文或正式技术报告", "跨模型复现", "替代机制对照", "预注册干预"],
            "action_boundary": {"allowed": ["提出机制假设", "设计安全测试", "记录不确定性"], "forbidden": ["认证主观体验", "以意识叙事赋予或剥夺权利"]},
            "route_requests": [{"source": "D", "target": "K", "purpose_profile": "research"}, {"source": "K", "target": "W", "purpose_profile": "audit"}, {"source": "P", "target": "D", "purpose_profile": "research"}],
        },
        "metadata": {"source": "uploaded Chinese commentary on J-space", "no_definition": True},
    }


def build_duan():
    frames = [
        frame("G_FOUNDER", "founder-researcher", "DIKWP theory and system creation", "open new semantic and engineering possibilities", "owner", "portfolio"),
        frame("G_MESH", "MESH² method guardian", "co-equal semantic network", "prevent hierarchy and definition capture", "reviewer", "method"),
        frame("G_MAINT", "external maintainer", "source-first open source", "run, review and maintain code", "maintainer", "repository"),
        frame("G_REVIEW", "independent researcher", "falsifiability and replication", "separate evidence from narrative", "reviewer", "research"),
        frame("G_ADOPT", "field adopter", "real-world scenario", "obtain useful and accountable outcomes", "operator", "deployment"),
        frame("G_STUDENT", "student contributor", "learning and contribution", "find a clear entry task", "participant", "individual"),
        frame("G_GOV", "governance observer", "rights, responsibility and public risk", "preserve accountability and appeal", "reviewer", "institution"),
        frame("G_PUBLIC", "public reader", "understanding the portfolio", "distinguish testable work from speculative narratives", "participant", "public"),
    ]
    atoms = [
        atom("G_D1", "D", "The public profile displayed 193 repositories, 0 Projects, 0 Packages, 214 Stars and 311 followers on 2026-07-18.", "G_PUBLIC", "GitHub public profile", .95, tags=["portfolio", "github"]),
        atom("G_D2", "D", "The DIKWP-MESH² repository publicly states that all 25 ordered DIKWP×DIKWP transformations are first-class and that Purpose is distributed and revisable.", "G_MESH", "DIKWP-MESH² README", .95, tags=["mesh", "25-transform"]),
        atom("G_I1", "I", "Many repository names are alternative projections of overlapping problems: semantic transformation, purpose, evidence, agency, continuity and future action.", "G_MESH", "portfolio synthesis", .78, tags=["overlap", "projection"]),
        atom("G_I2", "I", "ZIP-first public roots impose a high transition cost from attention to file-level review and contribution.", "G_MAINT", "representative repository inspection", .88, tags=["source-first", "maintenance"]),
        atom("G_K1", "K", "A stable public research program needs a root semantic runtime that indexes observer, context, purpose, evidence and transformation loss before project naming.", "G_REVIEW", "cross-repository analysis", .8, tags=["root-runtime"]),
        atom("G_K2", "K", "Named systems can remain useful task handles while being prohibited from becoming universal ontologies.", "G_MESH", "MESH² correction", .85, tags=["task-contract"]),
        atom("G_W1", "W", "The portfolio should preserve speculative branches without allowing them to consume the same authority as independently replicated work.", "G_GOV", "governance judgment", .82, tags=["evidence-gradient"]),
        atom("G_W2", "W", "External disagreement and failure should change the semantic mesh and project routing rather than merely add comments.", "G_REVIEW", "open science judgment", .84, tags=["feedback", "repair"]),
        atom("G_P1", "P", "Transform incomplete and conflicting semantic resources into auditable, revisable and purpose-indexed inquiry and action.", "G_FOUNDER", "recurring DIKWP mission", .9, tags=["mission"]),
        atom("G_P2", "P", "Enable strangers to run, challenge, modify and maintain the public system without inheriting a fixed ontology.", "G_MAINT", "open-source purpose", .9, tags=["commons"]),
        atom("G_P3", "P", "Protect affected people from actions that exceed evidence, authorization or appeal boundaries.", "G_GOV", "public-purpose frame", .88, tags=["accountability"]),
        atom("G_DEF1", "K", "Artificial consciousness is the single essence of the whole portfolio.", "G_PUBLIC", "possible external simplification", .2, "definition", tags=["concept-capture"]),
        atom("G_DEF2", "P", "Purpose is the immutable top controller of all DIKWP processing.", "G_GOV", "hierarchical interpretation", .15, "ontology-claim", tags=["purpose-monarchy"]),
    ]
    # Full 25 transformation alphabet represented using the five main atoms.
    representatives = {"D": "G_D2", "I": "G_I1", "K": "G_K1", "W": "G_W1", "P": "G_P1"}
    transforms = []
    idx = 1
    for s in "DIKWP":
        for t in "DIKWP":
            transforms.append(transform(
                f"G_T{idx:02d}", representatives[s], representatives[t], s, t, "G_MESH",
                f"Portfolio root analysis instantiates {s}→{t} as a co-equal, frame-indexed transformation rather than a hierarchy step.",
                prov="DIKWP-MESH² 25-transform completeness example", confidence=.76, reversible=(s == t), loss=.08 if s == t else .16,
                residuals=["Transformation output remains observer/context/purpose indexed."],
                falsifier="Show that the transformation is inapplicable to the declared task and preserve the omission as a justified residual."
            ))
            idx += 1
    rels = [
        relation("GR1", "Across the portfolio, a recurring problem is how to transform incomplete, inconsistent and observer-dependent semantic resources into inspectable action without erasing residuals.", ["G_FOUNDER", "G_MESH", "G_REVIEW", "G_ADOPT", "G_GOV"], unresolved=["G_PUBLIC"], evidence=.84, routes=.96, residuals=["Individual projects emphasize different scales and domains."], falsifier="A representative portfolio audit finds no shared transformation or audit problem across major systems."),
        relation("GR2", "Repository names and concepts are task handles and observer-purpose projections; they should not be treated as a fixed ontology of reality.", ["G_MESH", "G_REVIEW", "G_MAINT", "G_PUBLIC"], oppose=["G_FOUNDER"], unresolved=["G_ADOPT"], evidence=.78, routes=.9, residuals=["Branding and project navigation still require stable temporary names."], falsifier="Demonstrate that one named system has observer-independent necessary and sufficient boundaries across all uses."),
        relation("GR3", "Purpose should be represented as a distributed and revisable field with conflicts, delegation, suspension and withdrawal rather than a single privileged top controller.", ["G_MESH", "G_GOV", "G_ADOPT", "G_REVIEW"], oppose=["G_FOUNDER"], evidence=.86, routes=.95, residuals=["A task may still designate a temporary primary purpose under explicit authorization."], falsifier="Show a complex multi-actor task where one immutable purpose remains legitimate and sufficient under all context changes."),
        relation("GR4", "A project becomes public knowledge only when external people can inspect, run, challenge, repair and version it.", ["G_MAINT", "G_REVIEW", "G_STUDENT", "G_ADOPT", "G_PUBLIC"], unresolved=["G_FOUNDER"], evidence=.9, routes=.82, residuals=["Early speculative work can remain pre-publication."], falsifier="Show sustained external adoption and correction without inspectable source or contributor pathways."),
        relation("GR5", "The next key system should act before project naming: it should decompose claims, run all relevant transformations, preserve obstructions and compile task-specific semantic contracts.", ["G_MESH", "G_REVIEW", "G_MAINT", "G_GOV"], unresolved=["G_FOUNDER", "G_ADOPT"], evidence=.82, routes=.94, residuals=["The runtime itself must avoid becoming another privileged ontology."], falsifier="An existing public system already enforces these gates across the portfolio in source-first form."),
        relation("GR6", "Artificial consciousness is the single essence that unifies all projects.", ["G_PUBLIC"], oppose=["G_MESH", "G_REVIEW", "G_MAINT", "G_GOV", "G_ADOPT"], evidence=.2, routes=.3, definition_dependency=.9, residuals=["The label does not distinguish scientific, engineering, governance and communication purposes."], falsifier="Show that all projects require and empirically support one consciousness criterion."),
    ]
    hypers = [
        hyper("GH1", "conflict", ["G_DEF1", "GR1", "GR2"], ["G_PUBLIC", "G_MESH", "G_REVIEW"], "A single artificial-consciousness label compresses multiple problem relations and purposes."),
        hyper("GH2", "purpose-conflict", ["G_P1", "G_P2", "G_P3"], ["G_FOUNDER", "G_MAINT", "G_GOV"], "Innovation speed, open maintainability and public accountability can conflict and require negotiation."),
        hyper("GH3", "obstruction", ["G_I2", "GR4"], ["G_MAINT", "G_FOUNDER"], "ZIP-first delivery obstructs file-level external participation even when the internal package is complete."),
        hyper("GH4", "power-asymmetry", ["G_DEF2", "G_P3"], ["G_FOUNDER", "G_GOV"], "A purpose monarchy can erase the purposes and appeal rights of affected actors."),
    ]
    return {
        "bundle_id": "BUNDLE-DUAN-ROOT-MISSION-2026",
        "title": "段玉聪 GitHub 使命的 DIKWP-MESH² 无定义语义根分析",
        "frames": frames,
        "atoms": atoms,
        "transformations": transforms,
        "hyper_relations": hypers,
        "candidate_relations": rels,
        "residual_clusters": [
            {"temporary_handle": "semantic-name-loss", "residuals": ["一个项目名称压缩了哪些观察者、目的和冲突"], "affected_relations": ["GR2", "GR6"], "why_existing_axes_fail": "D/I/K/W/P 类型不能直接表达命名行为造成的语义损失和权力集中。", "candidate_measurements": ["命名前后分支保留率", "不同观察者误解率", "项目合并可逆性"], "discriminator_experiment": "将同一语义束分别以单一概念标题和多分支语义契约发布，比较外部理解、复现与争议结构。", "rollback_condition": "若命名不显著改变理解与路线，则将该轴并入观察者索引。"},
            {"temporary_handle": "external-world-revision-depth", "residuals": ["外部反馈是否只改变文本，还是改变转换算子和项目资源"], "affected_relations": ["GR4", "GR5"], "why_existing_axes_fail": "普通维护指标不能区分表面评论与深层语义/算子更新。", "candidate_measurements": ["失败引发的schema变更", "路线重排", "项目终止", "非创始release"], "discriminator_experiment": "选择三项外部反驳，记录它们是否改变语义原子、转换规则、目的场和资源分配。", "rollback_condition": "若深度无法可靠记录，则仅保留事件谱系。"},
            {"temporary_handle": "purpose-authority-distance", "residuals": ["提出目的者、授权者、受影响者和执行者之间的距离"], "affected_relations": ["GR3"], "why_existing_axes_fail": "Purpose 类型本身没有表达目的来源、授权和受影响者代表性。", "candidate_measurements": ["授权链长度", "可撤销性", "受影响者参与度", "申诉路径"], "discriminator_experiment": "在同一行动方案上改变目的授权结构，比较门控、冲突和可接受性。", "rollback_condition": "若权限系统已经完全表达该差异，则作为Purpose子索引而非独立轴。"},
        ],
        "inquiry": {
            "question": "在不把人工意识、数字生命、Purpose 或任何系统名称固定为本体的前提下，段玉聪现有 GitHub 资产跨观察者、跨目的、跨场景的稳定问题关系是什么，下一项行动应如何被编译？",
            "purpose": "恢复 DIKWP-MESH² 初心，把项目组合从概念堆叠转为无定义语义询问、实验和行动契约",
            "competing_purposes": ["前沿理论开拓", "开源维护", "外部复现", "真实场景采用", "公共风险治理", "人才培养"],
            "purpose_revision_rule": "任何Purpose均可因新证据、受影响者异议、资源变化或失败结果被修订、暂停或替换；不得由单一项目名称永久垄断。",
            "scope": "2026-07-18 可见公开 GitHub 资产与已上传 DIKWP-Mesh 4.0 材料",
            "evidence_requirements": ["公开仓库快照", "MESH² 25变换覆盖", "外部运行回执", "冲突和残余账本", "至少一个可证伪实验"],
            "allowed_outputs": ["稳定关系候选", "观察者分支", "不可粘合阻碍", "临时新轴", "项目门禁", "行动实验"],
            "forbidden_outputs": ["人工意识的统一定义", "Purpose顶层君主", "用系统名称替代证据", "把语义稳定当外部事实"],
            "action_boundary": {"allowed": ["将现有项目重索引为语义束", "阻止概念捕获", "生成实验与合并建议", "创建Draft PR"], "forbidden": ["自动删除仓库", "自动代表段玉聪发布立场", "自动合并或授权高风险行动"]},
            "route_requests": [{"source": "D", "target": "P", "purpose_profile": "research", "top_k": 8}, {"source": "P", "target": "P", "purpose_profile": "negotiation", "top_k": 8}, {"source": "K", "target": "D", "purpose_profile": "audit", "top_k": 8}, {"source": "W", "target": "P", "purpose_profile": "action", "top_k": 8}],
            "kill_conditions": ["系统输出单一观察者无范围定义并把它当事实", "Purpose被设置为不可修订的最高控制器", "冲突和残余在汇总中被消失", "项目门禁没有外部可证伪条件", "系统以自动化名义修改在线仓库或代表本人发言"],
        },
        "project_spec": {
            "project_name": "DIKWP-MESH² ROOTS OS",
            "observer_count": 8,
            "transform_classes_covered": 25,
            "canonical_definition_count": 0,
            "projection_statements": ["named systems are task handles", "invariants are candidates"],
            "residual_count": 11,
            "external_test_count": 3,
            "action_contract_count": 3,
            "source_first": True,
            "independent_reviewer": False,
            "linear_hierarchy_only": False,
            "immutable_global_purpose": False
        },
        "metadata": {"source": "GitHub public pages, DIKWP-MESH² README, uploaded DIKWP-Mesh 4.0 package", "immutable_purpose": False, "no_definition": True},
    }


def classify_repo(name, desc):
    text=(name+" "+desc).lower()
    tags=[]
    if any(k in text for k in ["mesh", "semantic", "resonance", "accord"]): tags.append("semantic-mesh")
    if any(k in text for k in ["pact", "audit", "proof", "mandate", "assurance", "steward", "standard"]): tags.append("assurance-governance")
    if any(k in text for k in ["conscious", "xperience", "lucid", "genesis"]): tags.append("consciousness-inquiry")
    if any(k in text for k in ["life", "alive", "vita", "continu", "everself"]): tags.append("life-continuity")
    if any(k in text for k in ["cosmos", "omega", "aeon", "syntropy", "planck"]): tags.append("cosmic-hypotheses")
    if any(k in text for k in ["praxis", "future", "civitas", "moira", "foresight"]): tags.append("future-action")
    if any(k in text for k in ["agent", "benchmark", "nexus"]): tags.append("agent-engineering")
    return tags or ["unclassified"]


def build_snapshot():
    source = Path("/mnt/data/nexus_extract/DIKWP_NEXUS_FORGE_OS_v1.0_CN/data/github_public_snapshot_2026-07-17.json")
    if source.exists():
        old=json.loads(source.read_text(encoding="utf-8"))
        repos=old["repositories"]
    else:
        repos=[]
    latest=[
        {"name":"DIKWP-AccordMesh-OS","description":"Active Inter-AI Federation for Semantic Exchange, Energy-Aware Coordination, Purpose Covenants and Auditable Alliances.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["DIKWP_AccordMesh_InterAI_Alliance_OS_Platform_Package.zip","LICENSE","README.md"],"evidence":"root_observed"},
        {"name":"DIKWP-MANDATE-","description":"Multi-Actor Authorization and Negotiated Deployment with Accountability, Termination and Evolution.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["DIKWP_MANDATE2_MVP.zip","LICENSE","README.md"],"evidence":"root_observed"},
        {"name":"DIKWP-NEXUS-FORGE-OS-v1.0","description":"Normalize · Extract · eXecute · Unite · Sustain.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["DIKWP_NEXUS_FORGE_OS_Duan_Yucong_Ecosystem_Compiler_v1.0_CN.zip","LICENSE","README.md"],"evidence":"root_observed"},
        {"name":"DIKWP-PRAXIS-WorldLab-v1.0","description":"Open Action OS for Shaping Uncertain Futures.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["ZIP","LICENSE","README.md"],"evidence":"profile_listing_plus_root_pattern"},
        {"name":"DIKWP-PRAXIS-","description":"开源未来塑造、现实干预与共同行动演化系统.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["ZIP","LICENSE","README.md"],"evidence":"profile_listing_plus_root_pattern"},
        {"name":"DIKWP-FutureForge-Commons-OS","description":"Action Defines Future · Evidence Earns Adoption · Commons Preserve Agency.","stars":2,"commits":3,"forks":0,"issues":0,"pull_requests":0,"releases":0,"updated":"2026-07-17","root_files":["ZIP","LICENSE","README.md"],"evidence":"profile_listing_plus_root_pattern"}
    ]
    by={r["name"]:r for r in repos}
    for r in latest: by[r["name"]]=r
    selected=[]
    for r in by.values():
        x=dict(r)
        x["semantic_tags"]=classify_repo(x.get("name",""),x.get("description",""))
        x["semantic_family"]=x["semantic_tags"][0]
        x["source_first"]=bool(x.get("root_files")) and not any(str(f).lower().endswith(".zip") or str(f)=="ZIP" for f in x.get("root_files",[]))
        selected.append(x)
    selected.sort(key=lambda x:x["name"])
    return {
        "snapshot_id":"YUCONGDUAN-GITHUB-REPRESENTATIVE-2026-07-18",
        "owner":"YucongDuan",
        "profile":{"repository_count":193,"projects_count":0,"packages_count":0,"stars_count":214,"followers_count":311,"observed_at":"2026-07-18","source_url":"https://github.com/YucongDuan?tab=repositories","caveat":"Profile figures are a time-stamped public-page observation. Repository records are a representative carry-forward from 2026-07-17 plus directly observed recent entries, not a complete authenticated API export."},
        "methodology":"Representative public snapshot used for semantic family analysis; names and descriptions are treated as projections, not definitions of project essence.",
        "repositories":selected
    }


def main():
    write(ROOT/"examples/life_no_definition_bundle.json", build_life())
    write(ROOT/"examples/jspace_semantic_bundle.json", build_jspace())
    write(ROOT/"examples/duan_repo_mission_bundle.json", build_duan())
    write(ROOT/"data/github_public_snapshot_2026-07-18.json", build_snapshot())
    write(ROOT/"examples/hierarchical_capture_spec.json", {
        "project_name":"Hypothetical Consciousness Definition System",
        "observer_count":1,
        "transform_classes_covered":5,
        "canonical_definition_count":4,
        "projection_statements":[],
        "residual_count":0,
        "external_test_count":0,
        "action_contract_count":0,
        "source_first":False,
        "independent_reviewer":False,
        "linear_hierarchy_only":True,
        "immutable_global_purpose":True
    })

if __name__=="__main__": main()

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs' / '段玉聪_DIKWP-MESH²_ROOTS_无定义语义本质发现意图场路由与项目去概念化系统_v1.0_CN_最终版.docx'
analysis = json.loads((ROOT/'outputs/demo/analysis.json').read_text(encoding='utf-8'))
atlas = json.loads((ROOT/'outputs/demo/repo_semantic_atlas.json').read_text(encoding='utf-8'))
life = json.loads((ROOT/'outputs/life/analysis.json').read_text(encoding='utf-8'))
jspace = json.loads((ROOT/'outputs/jspace/analysis.json').read_text(encoding='utf-8'))
bad_gate = json.loads((ROOT/'outputs/hierarchical_capture_gate.json').read_text(encoding='utf-8'))
registry = json.loads((ROOT/'outputs/demo/transformation_matrix.json').read_text(encoding='utf-8'))['matrix']
mission_bundle = json.loads((ROOT/'examples/duan_repo_mission_bundle.json').read_text(encoding='utf-8'))

TITLE='DIKWP-MESH² ROOTS OS v1.0'
SUBTITLE='段玉聪无定义语义本质发现、分布式意图场路由与项目去概念化关键系统'


def set_run_font(run, east='Noto Sans CJK SC', latin='Liberation Sans'):
    run.font.name = latin
    run._element.rPr.rFonts.set(qn('w:eastAsia'), east)


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tc_pr.append(shd)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    node = OxmlElement('w:tblHeader')
    node.set(qn('w:val'), 'true')
    tr_pr.append(node)


def set_cell_margins(cell, top=80, start=90, bottom=80, end=90):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v)); node.set(qn('w:type'),'dxa')


def set_col_widths(table, widths):
    for row in table.rows:
        for i,w in enumerate(widths):
            if i < len(row.cells): row.cells[i].width = Cm(w)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r=paragraph.add_run('第 ');set_run_font(r)
    fld1=OxmlElement('w:fldChar');fld1.set(qn('w:fldCharType'),'begin')
    instr=OxmlElement('w:instrText');instr.set(qn('xml:space'),'preserve');instr.text='PAGE'
    fld2=OxmlElement('w:fldChar');fld2.set(qn('w:fldCharType'),'end')
    r._r.append(fld1);r._r.append(instr);r._r.append(fld2)
    r2=paragraph.add_run(' 页');set_run_font(r2)


def add_heading(doc,text,level=1):
    p=doc.add_paragraph(text,style=f'Heading {level}')
    for r in p.runs:set_run_font(r)
    p.paragraph_format.keep_with_next=True
    return p


def add_para(doc,text,style=None,indent=True):
    p=doc.add_paragraph(style=style)
    p.paragraph_format.space_after=Pt(5)
    p.paragraph_format.line_spacing=1.18
    if indent and style is None:p.paragraph_format.first_line_indent=Cm(.74)
    r=p.add_run(text);set_run_font(r)
    return p


def add_bullet(doc,text,level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.08
    r=p.add_run(text);set_run_font(r);return p


def add_callout(doc,title,text,fill='EAF3F7'):
    t=doc.add_table(rows=1,cols=1);t.alignment=WD_TABLE_ALIGNMENT.CENTER;set_repeat_table_header(t.rows[0])
    c=t.cell(0,0);set_cell_shading(c,fill);set_cell_margins(c,150,180,150,180)
    p=c.paragraphs[0];r=p.add_run(title);r.bold=True;r.font.size=Pt(11);set_run_font(r)
    p2=c.add_paragraph();p2.paragraph_format.space_after=Pt(0);p2.paragraph_format.line_spacing=1.14
    r2=p2.add_run(text);set_run_font(r2)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


def add_table(doc,headers,rows,widths=None,font_size=8.4):
    rows=list(rows);t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER
    h=t.rows[0];set_repeat_table_header(h)
    for i,x in enumerate(headers):
        c=h.cells[i];set_cell_shading(c,'D9EAF2');set_cell_margins(c);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p=c.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        r=p.add_run(str(x));r.bold=True;r.font.size=Pt(font_size);set_run_font(r)
    for row in rows:
        cells=t.add_row().cells
        for i,val in enumerate(row):
            c=cells[i];set_cell_margins(c);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=c.paragraphs[0];p.paragraph_format.space_after=Pt(0)
            r=p.add_run(str(val));r.font.size=Pt(font_size);set_run_font(r)
    if widths:set_col_widths(t,widths)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


def add_image(doc,path,caption,width=16.4):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    shape=p.add_run().add_picture(str(path),width=Cm(width))
    shape._inline.docPr.set('descr',caption);shape._inline.docPr.set('title',caption)
    cp=doc.add_paragraph();cp.alignment=WD_ALIGN_PARAGRAPH.CENTER;cp.paragraph_format.space_after=Pt(7)
    r=cp.add_run(caption);r.italic=True;r.font.size=Pt(9);set_run_font(r)


def build_styles(doc):
    normal=doc.styles['Normal'];normal.font.name='Liberation Sans';normal._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');normal.font.size=Pt(10.5);normal.paragraph_format.line_spacing=1.18;normal.paragraph_format.space_after=Pt(5)
    for name,size,color,bold in [('Title',26,'17384F',True),('Subtitle',15,'3C6278',False)]:
        st=doc.styles[name] if name in doc.styles else doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st.font.name='Liberation Sans';st._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');st.font.size=Pt(size);st.font.color.rgb=RGBColor.from_string(color);st.font.bold=bold;st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for i,size in [(1,17),(2,14),(3,12)]:
        st=doc.styles[f'Heading {i}'];st.font.name='Liberation Sans';st._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=RGBColor(20,76,102) if i<3 else RGBColor(47,83,100);st.paragraph_format.space_before=Pt(9 if i==1 else 6);st.paragraph_format.space_after=Pt(5);st.paragraph_format.keep_with_next=True


def title_page(doc):
    p=doc.add_paragraph(style='Title');p.add_run(TITLE)
    for r in p.runs:set_run_font(r)
    p2=doc.add_paragraph(style='Subtitle');p2.add_run(SUBTITLE)
    for r in p2.runs:set_run_font(r)
    for _ in range(2):doc.add_paragraph()
    add_callout(doc,'系统边界','本系统不为“生命、意识、自我、经验、意图、价值、数字生命”等名称给出观察者无关的终局定义。所有名称只作为语义探究入口；输出必须保留观察者、情境、目的、证据、冲突、残余、转换路径和可撤销条件。','E7F2F5')
    add_table(doc,['交付字段','内容'],[
        ('版本','v1.0.0 参考实现'),('生成日期','2026-07-18'),('核心方法','DIKWP-MESH²：25 类共等 DIKWP×DIKWP 转换'),('主要输出','语义束、稳定关系候选、分支、阻碍、临时新轴、任务语义契约、项目诞生门禁'),('适用对象','段玉聪 GitHub 研究组合、人工意识/生命/经验等高争议问题、开放项目诞生前审查'),('不构成','概念终局、形而上证明、对个人或项目的价值评级、在线 GitHub 修改')
    ],widths=[4.0,12.2],font_size=9.5)
    add_para(doc,'本技术总规范的系统名称仅为版本索引和协作句柄，不主张 ROOTS 是新的本体、最高层或唯一框架。',indent=False)
    doc.add_page_break()


def nav(doc):
    add_heading(doc,'内容导航',1)
    items=['执行摘要：从“定义概念”回到“网状语义探究”','一、偏离诊断与 MESH² 初心恢复','二、段玉聪 GitHub 的语义结构与真正目标','三、ROOTS 系统边界与形式化对象','四、二十五类共等 DIKWP×DIKWP 变换','五、分布式意图场与非层级路由','六、定义隔离、语义粘合与阻碍保留','七、跨框架稳定关系、分支和概念逃逸','八、任务语义契约与项目诞生门禁','九、三个关键示例：生命、J-space 与段玉聪使命','十、仓库语义图谱与开放生态重构','十一、运行时、Schema、驾驶舱与复现','十二、九十天执行路线、治理与风险','十三、验证结果、真实边界与最终结论','附录 A—D：矩阵、数据结构、命令和参考资料']
    for x in items:add_bullet(doc,x)
    doc.add_page_break()


def content(doc):
    add_heading(doc,'执行摘要：从“定义概念”回到“网状语义探究”',1)
    add_para(doc,'用户指出此前交付逐渐偏离 DIKWP-Mesh 初心，这一判断是成立的。偏离并不主要发生在代码层，而发生在语义方法层：系统不断为“P-space、X-space、U2、数字生命、经验时代”等方向命名、分层和封装，名称随后又反过来支配分析；Purpose 被多次处理成最高控制平面；最终输出经常是“某系统是什么”的定义，而不是“在多个观察者、情境和目的之间，哪些关系较稳定、哪些关系冲突、哪些残余不能被翻译、哪些实验能够继续区分”的开放语义束。')
    add_para(doc,'DIKWP-MESH² 的更严格立场不是拒绝名称，也不是拒绝工程系统，而是拒绝让名称先于问题、让线性层级代替网状变换、让单一目的取代目的协商。D、I、K、W、P 是共等语义资源角色，D→I→K→W→P 只是 25 类有向变换中的一条路线。P 可以影响数据选择、关系构造、知识学习和价值注意，但数据、关系、知识、价值和外部结果也必须能够反向修改、限制、暂停和撤销目的。')
    add_callout(doc,'本次关键调整','不再交付一个声称“定义真正本质”的系统，而交付一个在任何新概念和新项目出现之前运行的根语义系统：它隔离定义性句子，展开全部 25 类变换，保留无法粘合的冲突，提出可撤销的新轴，编译任务语义契约，并阻断那些正在制造概念本体、目的君主或不可检验新仓库的提案。')
    add_para(doc,f'系统参考运行在八个观察者框架、十三个语义原子、二十五个转换事件、四个超关系和六个候选关系上完成分析。二十五类变换覆盖率为 {analysis["transformation_coverage"]["coverage_ratio"]:.0%}，每一类 D/I/K/W/P 的入度和出度均为 5，未触发 Purpose 特权警告。系统识别出两个跨框架稳定关系候选：其一，段玉聪研究组合反复面对的根问题是如何把不完整、相互冲突、观察者依赖的语义资源转化为可检查行动，同时不删除残余；其二，一个项目只有在外部人员能够检查、运行、挑战、修复和版本化之后，才真正进入公共知识。')
    add_para(doc,'系统同时保留三条支持分支：Purpose 应当是分布式、可修订的场；关键根系统应在项目命名前运行；仓库名和概念名只是任务句柄与观察者—目的投影。对于“人工意识是统一所有项目的单一本质”这一命题，系统没有用平均分强行调和，而将其标记为跨框架不可粘合分支。')
    add_image(doc,ROOT/'assets'/'architecture_cn.png','图 1  DIKWP-MESH² ROOTS OS 总体架构')

    add_heading(doc,'一、偏离诊断与 MESH² 初心恢复',1)
    add_heading(doc,'1.1 偏离一：命名被误当成发现',2)
    add_para(doc,'命名在科研和工程中不可避免。问题不在于出现“人工意识”“数字生命”“主观体验”“宇宙意图”等名称，而在于名称是否被当作已经找到的对象边界。一个名称通常压缩了不同观察者的测量能力、问题历史、制度需求、传播策略和行动目的。名称可以帮助进入问题，也可能遮蔽问题。ROOTS 因此把名称保存为 handle，而不是 entity：每次使用名称时，都要求附带观察者、情境、目的、时间、尺度、来源和“不支持什么”。')
    add_para(doc,'例如，“经验”在强化学习研究者那里可能指状态—行动—后果轨迹；在现象学语境中可能指第一人称感受；在软件治理中可能指失败和修复的历史；在用户研究中可能指服务体验。若系统先把这些用法合并成一个“经验本体”，它会制造虚假的统一。正确做法是保留不同框架，寻找它们之间可转换的关系，记录转换造成的语义损失，并通过区分实验判断哪些分支可以局部粘合。')
    add_heading(doc,'1.2 偏离二：把 DIKWP 画成金字塔',2)
    add_para(doc,'传统 DIKW 容易被画成从数据到智慧的单向金字塔。加入 Purpose 后，若简单把 P 放在顶层，就会产生“目的君主”：目的选择数据、定义关系、组织知识、安排价值，却不允许这些资源反过来改变目的。MESH² 的关键突破恰恰是取消这一先验等级。P→D 说明目的影响注意与采样；D→P 说明新观测可以触发、限制或终止目的。P→W 说明目的影响价值注意；W→P 说明受影响者和不可通约价值可以限制目的。P→P 更要求目的之间能够协商、委托、暂停、退出和版本化。')
    add_heading(doc,'1.3 偏离三：把输出写成终局系统定义',2)
    add_para(doc,'此前一些交付将复杂问题压缩为单个操作系统，并在结尾给出“最终系统定义”。这在产品传播上清晰，在 MESH² 方法上却可能过早封闭概念空间。ROOTS 的输出格式改为六部分：跨框架稳定关系候选、保留分支、阻碍、残余、临时新轴和任务语义契约。任何“最终”只表示当前版本冻结，不表示对世界终结。')
    add_image(doc,ROOT/'assets'/'correction_loop_cn.png','图 2  从概念定义循环调整为网状语义探究循环')

    add_heading(doc,'二、段玉聪 GitHub 的语义结构与真正目标',1)
    profile=atlas['profile']
    add_para(doc,f'本系统采用 2026 年 7 月 18 日公开页面快照。页面当时显示约 {profile["repository_count"]} 个仓库、{profile["projects_count"]} 个 Projects、{profile["packages_count"]} 个 Packages、{profile["stars_count"]} 个 Stars 和 {profile["followers_count"]} 位 followers。页面数据具有缓存和持续变化特征，因此只能作为时间戳信号，而不能被当成永久、完整、经认证的统计。本地代表性快照包含 {atlas["metrics"]["representative_repo_count"]} 条仓库记录，分入 {atlas["family_count"]} 个初步语义家族；该样本不是完整授权 API 审计。')
    add_table(doc,['公开指标','快照值','MESH² 解释边界'],[
        ('Repositories',profile['repository_count'],'表达和原型密度信号，不等于独立问题数量'),('Projects',profile['projects_count'],'缺少公开跨仓库问题控制面信号'),('Packages',profile['packages_count'],'缺少统一模块分发入口信号'),('Stars',profile['stars_count'],'外部注意信号，不等于复现、采用或科学证据'),('Followers',profile['followers_count'],'受众信号，不等于贡献者与共同维护者'),('代表性记录',atlas['metrics']['representative_repo_count'],'用于语义分支观察，不可外推全部仓库内容')
    ],widths=[3.2,2.4,10.6],font_size=9)
    add_para(doc,'从 MESH² 角度看，仓库数量本身不是问题，仓库之间的语义关系是否可见才是问题。当前许多仓库名称围绕人工意识、生命连续性、宇宙意图、主动未来、可信智能体、语义网络和治理展开。它们可能是不同目的的有效分支，也可能是同一根问题的重复包装。若没有观察者与目的索引，外部读者只能把名称当作项目本体；若直接按词汇相似自动合并，又会抹杀真实差异。ROOTS 采取第三条路径：高重叠只触发交叉分析，由人类比较问题、证据、受影响者、行动边界和维护责任。')
    fam_rows=[(x['family'],x['count'],'、'.join(x['repositories'][:4])+('…' if x['count']>4 else '')) for x in atlas['families']]
    add_table(doc,['暂时语义家族','代表数量','部分仓库句柄'],fam_rows,widths=[4,2,10.2],font_size=8)
    add_image(doc,ROOT/'assets'/'repo_semantic_families_cn.png','图 3  仓库名称作为共享根问题的观察者—目的分支')
    add_para(doc,'ROOTS 从仓库组合中提出四个根问题候选：如何把不完整、冲突、观察者依赖的语义转化为可审计行动；如何让 Purpose 可修订而又保持责任；如何让外部证据、失败和独立观察者修改语义内容与转换算子；如何把大型组合表示为共享问题的分支，而不是不断堆叠命名本体。这四个根问题比任何单一仓库名称更接近段玉聪当前要完成的使命。')

    add_heading(doc,'三、ROOTS 系统边界与形式化对象',1)
    add_heading(doc,'3.1 系统名称不是新本体',2)
    add_para(doc,'ROOTS 是 Relational、Observer-indexed、Open-ended、Transformation-complete、Semantic inquiry 的工作句柄。它不声称自己是 DIKWP 的最高层，也不取代 MESH²。更准确地说，它是 MESH² 原则的参考运行时，用来在名称、项目和行动被固定之前执行语义探究。')
    add_heading(doc,'3.2 观察者框架',2)
    add_para(doc,'基本框架写为 F=(O,C,P,T,S,M,A)，其中 O 是观察者或参与者，C 是情境，P 是当前目的，T 是时间，S 是尺度，M 是观测模态，A 是权限或责任。相同句子在不同框架中可以有不同语义地位。例如研究者提出“模型内部存在全局可用中间状态”是可检验机制命题；媒体提出“AI 意识诞生前夜”是传播叙事；监管者关心的是内部状态是否影响高风险行动；用户关心的是系统是否可能隐瞒风险。ROOTS 不把它们压成同一句话。')
    add_heading(doc,'3.3 语义原子与转换事件',2)
    add_para(doc,'语义原子 A=(id,type,expression,frame,provenance,confidence,mode,tags,supports,opposes,does-not-support)。type 只能是 D、I、K、W、P 之一，但这只是当前任务角色，不是表达的永久类别。转换事件 T 记录源原子、目标原子、源类型、目标类型、算子、框架、理由、来源、置信度、可逆性、语义损失、残余和证伪条件。')
    add_heading(doc,'3.4 超关系、阻碍和残余',2)
    add_para(doc,'二元边不足以表达“多个框架共同支持但一个关键主体反对”“一个目的授权、另一个目的否决”“同一语句在不同尺度发生语义反转”等结构。ROOTS 使用 HyperRelation 表示多成员关系，并把 conflict、obstruction、untranslatable、power-asymmetry 作为不可自动消除的对象。Residual 不是系统失败的垃圾桶，而是下一轮概念逃逸和新实验的入口。')
    add_heading(doc,'3.5 语义闭合而非概念闭合',2)
    add_para(doc,'所谓语义闭合，不是让所有人同意一个定义，而是在当前任务和证据范围内，D/I/K/W/P/R 之间形成足够稳定、可追溯、可行动又保留残余的关系结构。闭合的判据包括：主锚点可追溯；单位、数量级、分母和反向检查可执行；目的和授权可复核；冲突没有被删除；外部结果可以回写；Kill 条件明确。概念可以继续开放，行动契约可以暂时闭合。')

    add_heading(doc,'四、二十五类共等 DIKWP×DIKWP 变换',1)
    add_image(doc,ROOT/'assets'/'matrix_25_cn.png','图 4  二十五类共等变换矩阵')
    add_para(doc,'二十五类变换是 ROOTS 的最小原语字母表，不是全部高阶语义操作。真实分析可以组合、循环、并行和递归地执行这些原语，并在必要时引入新轴。每一个变换都应报告常见语义损失和恢复动作。以下按源资源分组说明。')
    for row in registry:
        source=row[0]['source']
        add_heading(doc,f'4.{list("DIKWP").index(source)+1} 以 {source} 为源的五类变换',2)
        rows=[]
        for x in row:
            rows.append((x['code'],x['operation'],x['question'],x['common_loss'],x['recovery']))
        add_table(doc,['代码','操作提示','主要问题','常见损失','恢复动作'],rows,widths=[1.5,3.0,4.3,3.4,4.2],font_size=7.3)
        add_para(doc,f'{source} 不是固定层级。当 {source} 作为源时，系统只表示当前转换的出发角色；同一表达在另一个框架中可以成为其他类型。完整分析应记录为何选择这条路、为何没有选择替代路，以及目的改变后路由是否发生变化。')

    add_heading(doc,'五、分布式意图场与非层级路由',1)
    add_heading(doc,'5.1 Purpose 不是最高本体',2)
    add_para(doc,'ROOTS 将 Purpose 表示为多个目的原子、授权关系、冲突关系、委托关系、暂停条件和撤销权组成的场。一个项目可能同时服务科学发现、公共安全、创始人表达、学生进入、场景采用、机构问责和维护可持续性。这些目的不能由单一总分自动合并，因为某些主体拥有否决权，某些授权只能在特定时间和尺度有效。')
    purpose_rows=[(x['purpose'],', '.join(x['frames'])) for x in analysis['purpose_field']['purposes']]
    add_table(doc,['目的投影','对应观察框架'],purpose_rows,widths=[10.4,5.8],font_size=8.5)
    add_heading(doc,'5.2 路由随目的场变化',2)
    add_para(doc,'同样的 D→P 问题，在 exploration 目的下可能优先通过多样路径以暴露新关系；在 audit 目的下会优先接触证据和残余；在 action 目的下会偏向直接、可逆和权限明确的路径。路由分数不是“真理概率”，只是当前目的配置下的工作排序。系统必须允许目的扰动实验：改变目的权重后，哪些结论稳定，哪些结论只是目的选择造成。')
    route_rows=[]
    for key, routes in list(analysis['route_suite'].items())[:4]:
        top=routes[0]
        route_rows.append((key,'→'.join(top['path']),','.join(top['operators']),top['score']))
    add_table(doc,['路由请求','优先路径','算子','参考分数'],route_rows,widths=[4.2,4.1,4.1,2.2],font_size=8.5)
    add_heading(doc,'5.3 目的的反向约束',2)
    add_para(doc,'任何目的都必须接受四类反向作用：观测反向作用，新的 D 可以终止原目的；关系反向作用，新的 I 可以暴露授权冲突；知识反向作用，K 可以证明目的不可实现或前提错误；价值反向作用，W 可以因伤害、权利和代际后果而否决目的。外部行动结果是更强的反向作用，必须进入下一版本目的场。')

    add_heading(doc,'六、定义隔离、语义粘合与阻碍保留',1)
    add_heading(doc,'6.1 定义隔离区',2)
    add_para(doc,'系统扫描 claim_mode 为 definition、universal-definition 或 ontology-claim 的原子，将其保留但降级为框架索引投影。隔离不是审查思想，而是防止一个句子在没有说明观察者和用途时获得不当权力。被隔离句子仍可参与转换，也可在特定任务中成为操作性约定，但必须附带适用域和失效条件。')
    add_heading(doc,'6.2 粘合条件',2)
    add_para(doc,'多个框架之间的关系只有在来源可追溯、转换路径可解释、语义损失可接受、关键反例已登记、目的冲突已处理且外部区分实验支持时，才可形成局部粘合。粘合结果是 invariant candidate，不是 definition。若支持面广但关键反对框架仍存在，系统输出 supported branch 或 contested branch。')
    add_heading(doc,'6.3 阻碍是资产',2)
    for obs in analysis['obstructions']:
        add_bullet(doc,f"[{obs['type']}] {obs['statement']} 处理策略：{obs['resolution_policy']}")
    add_para(doc,'对段玉聪生态而言，ZIP-first 是外部参与的工程阻碍；“人工意识单一标签统一全部项目”是语义阻碍；Purpose 君主会造成权力不对称阻碍。这些阻碍不应通过改名或生成更宏大的系统叙事消失，而应转化为 source-first 迁移、分支图、申诉和区分实验。')

    add_heading(doc,'七、跨框架稳定关系、分支和概念逃逸',1)
    add_heading(doc,'7.1 稳定关系不是本质定义',2)
    inv_rows=[(x['relation_id'],x['statement'],x['metrics']['semantic_stability'],x['status']) for x in analysis['invariant_mining']['all']]
    add_table(doc,['关系','陈述','稳定度','状态'],inv_rows,widths=[1.3,11.2,1.7,2.3],font_size=7.8)
    add_para(doc,'稳定度综合支持框架比例、观察者广度、目的广度、情境广度、证据强度、路由多样性、反对比例、定义依赖和残余负载。该算法只用于暴露关系结构，不应被解释为客观真理概率。对跨文化、跨学科、高风险任务，权重必须公开并接受替代算法比较。')
    add_heading(doc,'7.2 概念逃逸',2)
    add_para(doc,'当 D/I/K/W/P 的现有角色不能解释某组残余时，系统允许提出临时新轴。但新轴必须满足四项条件：明确说明现有轴为什么不足；列出可观察测量；给出能区分竞争分支的实验；设置回滚或退休条件。名称只是临时坐标，不能因为被命名就自动成为新概念、新学科或新仓库。')
    axis_rows=[(x['temporary_handle'],x['why_existing_axes_fail'],x['discriminator_experiment'],x['rollback_condition']) for x in analysis['concept_escape']]
    add_table(doc,['临时新轴','现有轴不足','区分实验','回滚条件'],axis_rows,widths=[3.0,4.5,4.7,4.3],font_size=7.7)
    add_para(doc,'三个参考新轴分别测量：目的提出者与授权者/受影响者之间的距离；命名压缩造成的语义损失；外部世界是否真的能够修改项目的内容、规则和资源。它们比继续发明“更高级意识空间”更接近当前需要被区分的真实变量。')

    add_heading(doc,'八、任务语义契约与项目诞生门禁',1)
    add_heading(doc,'8.1 任务语义契约',2)
    c=analysis['semantic_contract']
    add_para(doc,'语义契约允许概念保持开放，同时使具体任务暂时可执行。参考契约禁止输出观察者无关的终局定义、形而上认证和无范围的普遍命题；允许输出语义束、候选关系、实验和行动选项。它同时列出稳定关系候选、保留分支、未解决阻碍、临时新轴、证据要求、行动边界、Kill 条件和下一次复核触发。')
    add_table(doc,['契约字段','参考内容'],[
        ('任务',c['task']),('主任务目的',c['purpose_field']['primary_task_purpose']),('竞争目的','；'.join(c['purpose_field']['competing_purposes'])),('允许输出','；'.join(c['allowed_outputs'])),('禁止输出','；'.join(c['forbidden_outputs'])),('Kill 条件','；'.join(c['kill_conditions'])),('复核条件',c['review_after'])
    ],widths=[3.2,13.0],font_size=8.5)
    add_heading(doc,'8.2 项目诞生门禁',2)
    add_para(doc,'项目诞生门禁的任务不是评价项目好坏，而是判断一个探索性关系是否具备被包装成独立公共项目的最低条件。门禁检查定义捕获、层级泄漏、目的君主、观察者塌缩、残余删除、可检验缺口、行动缺口、开放缺口和维护缺口。')
    good=analysis['project_gate']
    add_table(doc,['项目规格','决定','捕获风险','关键说明'],[
        (good['project_name'],good['decision'],good['capture_risk'],'完成 25 类覆盖、保留残余、具有外部测试、source-first 与独立审查条件'),(bad_gate['project_name'],bad_gate['decision'],bad_gate['capture_risk'],'单向金字塔、多个终极定义、不可修改全局目的、零残余和零外部测试')
    ],widths=[4.2,5.2,2.0,5.0],font_size=8.2)
    add_para(doc,'参考 ROOTS 项目得到“可进入人类审查的项目诞生条件”，并不表示它已经获得段玉聪本人、机构或共同体批准；坏示例被直接阻断并要求重构为语义束。在线仓库的创建、合并、归档和删除永远不能由该算法自动执行。')

    add_heading(doc,'九、三个关键示例：生命、J-space 与段玉聪使命',1)
    add_heading(doc,'9.1 “生命”问题：用形态空间代替定义争夺',2)
    add_para(doc,'《Defining Life: A Conversation》汇集大量彼此冲突但富有信息的生命表述。讨论涉及代谢、复制、约束闭合、认知、主体性、观察者相对性、开放状态空间、规则变化和多维形态空间。论文第 22—23 页的图尤其说明：把不同自然、合成和理论系统放进相对形态空间，可以发现聚类、相关、空白区域和相变边界，而不必先决定一个普遍定义。ROOTS 对该材料的处理原则是：把每种表述记录为观察者框架下的关系投影，寻找可实验的子过程和跨框架关系，同时保留“生命是否自然种类”“学习是否必要”“观察者是否构成边界”等阻碍。')
    add_para(doc,f'生命示例分析包含 {life["input_summary"]["frames"]} 个框架、{life["input_summary"]["atoms"]} 个原子和 {life["input_summary"]["candidate_relations"]} 个候选关系。其核心产出不是“生命就是 X”，而是哪些关系可作为形态空间坐标、哪些定义依赖特定目的、哪些空白区域值得构造新实验。')
    add_heading(doc,'9.2 J-space 问题：分离机制、功能、叙事和体验',2)
    add_para(doc,'用户材料对 Anthropic J-space 研究作了高度拟人化传播，评论区同时出现机制主义、功能主义、生物自然主义、怀疑主义和市场营销批评。ROOTS 不预先定义“意识”，而把至少四类关系分开：内部表示与未来输出的局部因果关系；信息跨任务可用的功能关系；模型自述与训练叙事的语言关系；主观体验是否存在的形而上或现象学主张。前两类可以设计干预和复现实验，第三类需要来源与训练条件审计，第四类不能由前述结果自动推出。')
    add_para(doc,f'J-space 示例分析保留 {len(jspace["obstructions"])} 个阻碍，并通过 does-not-support 字段明确：内部概念可读出、可替换、会影响行为，不等于证明模型具有体验、人格或宇宙主体性。这样既不先验否定未来人工意识，也不把可解释性进展包装成意识证书。')
    add_heading(doc,'9.3 段玉聪使命：从“更多系统”转向“根问题—分支—外部反作用”',2)
    add_para(doc,'对段玉聪而言，真正要解决的问题不是选择“人工意识、数字生命、可信智能体、文明预测”中的某一个名称作为唯一主航道，而是建立一种能力：任何新问题都能被多观察者建模，任何目的都能被反向修订，任何概念都能暴露语义损失，任何项目都必须接受外部运行、失败和维护。ROOTS 因此应成为 MESH² 生态中的项目出生前根运行时，而不是与现有仓库竞争注意力的又一个宏大概念。')

    add_heading(doc,'十、仓库语义图谱与开放生态重构',1)
    add_heading(doc,'10.1 从项目本体到问题分支',2)
    add_para(doc,'仓库图谱不应把名称当成节点本体，而应把根问题、观察框架、目的、证据、行动和维护责任作为一等对象。一个仓库可以属于多个语义家族；同一问题可以有不同场景仓库；同一仓库也可承载多个实验分支。归并的单位不是标题，而是可组合模块、共享 Schema 和共同维护责任。')
    overlap_rows=[(x['left'],x['right'],x['overlap']) for x in atlas['high_overlap_pairs'][:12]]
    add_table(doc,['左仓库句柄','右仓库句柄','词汇重叠'],overlap_rows,widths=[7.1,7.1,2.0],font_size=7.3)
    add_para(doc,'上表仅是交叉审查触发器。例如 IntentEconomy 与 Intention-Economy 可能只是命名差异，也可能具有不同制度目的；ActiveConsciousness 与 FraudShield-ActiveConsciousness 可能是基础模块与特定场景。ROOTS 要求检查共享问题、输入输出、证据、用户、风险和维护者后再决定 Flagship、Module、Scenario、Experiment、Horizon 或 Archive。')
    add_heading(doc,'10.2 新仓库出生政策',2)
    for item in ['无法由现有模块、场景、Issue 或实验容纳的独立问题','至少三个观察者框架与两个竞争目的','完整或经审查说明的 25 类变换覆盖','至少一个外部区分实验与一个可复现运行入口','source-first 代码、Schema、测试、版本和许可证','非创始审查者、维护责任与退出条件']:
        add_bullet(doc,item)
    add_para(doc,'未满足条件的新构想仍可被完整保存，但身份应是 SemanticBundle、Hypothesis、AxisProposal、BenchmarkScenario、Adapter 或 Issue。这样不会丢失超前布局，同时避免名称增长速度继续高于验证和维护速度。')

    add_heading(doc,'十一、运行时、Schema、驾驶舱与复现',1)
    add_heading(doc,'11.1 Python 参考运行时',2)
    add_para(doc,'参考运行时包含 TransformRegistry、非层级路由器、稳定关系矿工、阻碍矿工、概念逃逸器、语义契约编译器、项目诞生门禁、仓库语义图谱和离线驾驶舱生成器。运行时不调用模型 API，不联网，不写入 GitHub，不处理用户身份数据。固定时间戳、规范化 JSON 和 SHA-256 用于确定性复现。')
    add_heading(doc,'11.2 机器可读 Schema',2)
    schemas=['ObserverFrame','SemanticAtom','TransformationEvent','HyperRelation','SemanticInquiryBundle','InvariantCandidate','SemanticObstruction','TemporarySemanticAxisProposal','TaskIndexedSemanticContract','ProjectGateReport','DIKWPRootsAnalysisRelease']
    add_table(doc,['Schema','用途'],[(x,{'ObserverFrame':'观察者/情境/目的索引','SemanticAtom':'D/I/K/W/P 语义原子','TransformationEvent':'变换路径、损失和残余','HyperRelation':'多成员支持、冲突和权力关系','SemanticInquiryBundle':'完整输入语义束','InvariantCandidate':'跨框架稳定关系候选','SemanticObstruction':'不可强行粘合的阻碍','TemporarySemanticAxisProposal':'临时新轴、实验和回滚','TaskIndexedSemanticContract':'当前任务可执行边界','ProjectGateReport':'项目诞生条件审计','DIKWPRootsAnalysisRelease':'版本化完整分析结果'}[x]) for x in schemas],widths=[5.0,11.2],font_size=8.5)
    add_heading(doc,'11.3 CLI 与离线驾驶舱',2)
    add_para(doc,'命令行支持 analyze、route、matrix、gate 和 atlas。离线驾驶舱把 25 类覆盖、稳定关系、分支、阻碍、临时新轴、意图场、语义契约、项目门禁和仓库图谱集中显示。HTML 将数据内嵌，不引用外部脚本、字体或网络服务，便于离线审查和归档。')
    add_table(doc,['命令','功能'],[
        ('dikwp-roots analyze <bundle> --snapshot <snapshot> --out <dir>','生成完整语义分析与驾驶舱'),('dikwp-roots route D P --purpose audit','查看指定目的场下的优先变换路由'),('dikwp-roots matrix --out matrix.json','导出 25 类原语'),('dikwp-roots gate <spec>','审查项目定义捕获和层级泄漏'),('dikwp-roots atlas <snapshot>','构建仓库语义图谱')
    ],widths=[7.0,9.2],font_size=8.2)

    add_heading(doc,'十二、九十天执行路线、治理与风险',1)
    phases=[('0—14 天','冻结无定义协议、25 类原语和 Purpose 场原则；建立唯一 GitHub Project。'),('15—30 天','把活跃仓库拆解成根问题、观察框架、证据、目的、场景和残余；完成高重叠对人工复核。'),('31—50 天','公开互测生命、J-space 与段玉聪使命三个问题；每类发布失败和阻碍。'),('51—70 天','对新项目提案运行项目诞生门禁；BLOCK 转为语义束，HOLD 补外部测试。'),('71—90 天','发布中英文协议、三份独立复现和一次非创始 Release；外部结果必须修改至少一个关系或算子。')]
    add_table(doc,['阶段','核心动作'],phases,widths=[3.2,13.0],font_size=8.8)
    add_heading(doc,'12.1 治理结构',2)
    add_para(doc,'建议至少建立方法维护者、Schema 维护者、外部复现者、场景观察者和受影响者代表五类角色。创始人可以提出框架和目的，但不能单独批准涉及自身项目的门禁结论。临时新轴超过一个版本仍无独立区分实验，应自动退休或降级。所有权重、阈值和算法变更必须保存 before/after 输出。')
    add_heading(doc,'12.2 主要风险',2)
    risk_rows=[('伪无定义','表面不定义，实际通过指标权重偷偷规定本质','公开权重、替代模型和反例'),('Purpose 隐性君主','把创始人使命写成默认目的','多目的场、授权与申诉'),('复杂性遮蔽','25 类矩阵成为新的形式主义','每项变换绑定真实问题和证伪'),('概念逃逸膨胀','临时新轴迅速变成新名词','到期、区分实验和回滚'),('仓库误伤','词汇相似被误判为重复','只触发人工交叉审查'),('外部形式化','邀请外部人员但不允许改变结论','要求外部结果进入版本差分'),('分数崇拜','稳定度或风险分被当真理','明确为任务排序，不代表本体')]
    add_table(doc,['风险','表现','控制'],risk_rows,widths=[3.0,6.2,7.0],font_size=8.3)

    add_heading(doc,'十三、验证结果、真实边界与最终结论',1)
    add_heading(doc,'13.1 参考实现验证',2)
    add_para(doc,'自动测试覆盖 25 类原语完整性、路由随目的变化、定义隔离、Purpose 非特权、稳定关系/阻碍/新轴生成、项目门禁、确定性哈希、仓库图谱边界、离线驾驶舱和 JSON Schema。最终发布前还需要执行 DOCX 渲染逐页检查、可访问性审计、ZIP 完整性和清洁解压复测。')
    add_table(doc,['验证对象','结果'],[
        ('25 类变换','25/25，所有类型入度与出度均为 5'),('参考分析 ID',analysis['analysis_id']),('参考分析 Hash',analysis['analysis_hash']),('稳定关系候选',len(analysis['invariant_mining']['invariant_candidates'])),('保留分支',len(analysis['invariant_mining']['branches'])),('阻碍',len(analysis['obstructions'])),('临时新轴',len(analysis['concept_escape'])),('好项目门禁',f"{good['decision']} / risk {good['capture_risk']}"),('坏项目门禁',f"{bad_gate['decision']} / risk {bad_gate['capture_risk']}")
    ],widths=[4.8,11.4],font_size=8.5)
    add_heading(doc,'13.2 真实边界',2)
    for item in ['本次 GitHub 图谱是代表性公开快照，不是完整授权 API 审计；数字会继续变化。','稳定关系评分是参考启发式，不是统计证明或客观本质概率。','系统不能自行决定段玉聪的真实意图，只能保存公开表达和经授权目的框架。','系统没有修改任何在线仓库，也不代表段玉聪、海南大学、WAAC 或 WCAC 采用或背书。','25 类变换是原语字母表，不保证覆盖所有未来语义操作；新操作必须以可检验方式演化。','无定义不等于无行动。高风险行动仍需要明确权限、责任、证据和人工决策。']:
        add_bullet(doc,item)
    add_heading(doc,'13.3 最终结论',2)
    add_callout(doc,'关键系统定义','DIKWP-MESH² ROOTS OS 是一个在概念被定义、项目被命名和行动被授权之前运行的根语义系统。它把名称拆回观察者—情境—目的索引的 D/I/K/W/P 资源，在全部 25 类共等变换中寻找跨框架稳定关系，同时保留分支、阻碍和残余；当现有概念空间不足时，它只提出带实验和回滚条件的临时新轴；当构想准备成为新项目时，它检查是否发生定义捕获、层级泄漏、Purpose 君主、残余删除或外部不可检验。')
    add_para(doc,'对段玉聪而言，最接近“改变世界”的下一步不是再给世界一个更宏大的概念，而是提供一种公共方法：任何人都能把自己的观察、目的、反例和行动带入同一个语义网；任何关系都能被外部结果修改；任何新名称都要证明它确实增加了区分能力；任何项目都必须先说明它解决了哪个根问题，并允许非创始人运行、质疑、修复和继承。')

    add_heading(doc,'附录 A：二十五类变换速查',1)
    flat=[x for row in registry for x in row]
    add_table(doc,['代码','源→目标','操作','问题'],[(x['code'],f"{x['source']}→{x['target']}",x['operation'],x['question']) for x in flat],widths=[1.5,1.8,4.0,9.0],font_size=7.4)
    add_heading(doc,'附录 B：建议引用与版本格式',1)
    add_para(doc,'建议中文引用：DIKWP-MESH² ROOTS OS 工作组（待确认），《段玉聪无定义语义本质发现、分布式意图场路由与项目去概念化系统》，v1.0，2026-07-18。正式发布前应补充作者、审稿人、机构、仓库地址、Release tag、DOI 和许可证。')
    add_para(doc,'建议机器引用：保存 `analysis_id`、`analysis_hash`、输入 bundle hash、Schema version 和 Git commit。任何截图、新闻稿和二次分析都应引用具体版本，不应笼统引用“DIKWP-MESH² 已经证明……”。')
    add_heading(doc,'附录 C：二十五类变换执行卡',1)
    add_para(doc,'下列执行卡不是对二十五类变换的终极定义，而是把每一类变换落实为可重复审查的问题。每张卡都要求记录输入来源、框架、语义损失、外部区分实验和不支持的结论。执行者可以修改操作提示，但必须保留变更原因和前后差分。')
    for x in flat:
        add_heading(doc,f"{x['code']} · {x['source']}→{x['target']} · {x['operation']}",2)
        add_para(doc,f"任务入口：{x['question']}。执行时先冻结源资源在当前观察者框架中的表达，不允许因为目标类型不同而回写源记录。随后至少构造一条主转换和一条替代转换，比较两条路径对关系、证据、权衡与目的产生的差异。若转换依赖未经声明的定义，应先把该定义移入隔离区。")
        add_para(doc,f"主要风险：{x['common_loss']}。该风险不能只靠提示语避免，必须在输出中记录语义损失、被压缩的差异、未进入目标资源的内容和受影响的观察者。恢复动作是：{x['recovery']}。恢复后仍无法翻译的部分进入 Residual Ledger，而不是被删去或强行归类。")
        add_para(doc,'最低证据要求包括：源原子及其 provenance、目标原子的生成理由、至少一个反例、一个目的扰动测试、一个观察者替换测试，以及一个能够使该转换失效的 falsifier。该变换产生的结果只支持当前任务中的关系或行动候选，不支持“源与目标天然存在固定等级”“该路径在所有情境中最优”或“目标资源比源资源更高级”等结论。')

    add_heading(doc,'附录 D：八个观察者框架的实际职责',1)
    frame_notes={
        'G_FOUNDER':'创始人框架负责提出新问题、连接远期布局与工程可行性。它的优势是跨领域联想和目的连续，风险是把个人意图误当公共目的、把新名称误当新对象。该框架必须公开 does-not-support，并允许维护者、采用者和治理主体否决现实行动。',
        'G_MESH':'MESH 方法框架负责检查 D/I/K/W/P 是否被重新层级化、Purpose 是否被君主化、冲突是否被平均掉。它不能因为维护“方法纯洁”而阻止一切应用，而应把方法边界转化为可运行的转换登记、残余账本和复核条件。',
        'G_REVIEW':'独立评审框架把叙事强度与证据强度分开，检查来源、反例、统计、复现和不支持结论。它不能仅以传统术语缺失否定创新，也不能因作者声誉降低证据要求。',
        'G_MAINT':'维护者框架关注源码入口、依赖、测试、版本、Issue、PR、Release 和继任。它揭示一个理论即使语义丰富，若不能被陌生人运行和修改，仍未进入公共工程生命史。维护便利也不能反向简化或删除科学分支。',
        'G_ADOPT':'场景采用者框架关注真实用户、责任主体、数据条件、成功指标、退出与回滚。它可以要求任务语义契约暂时闭合，但不能要求系统对概念作永久定义；采购或合作压力也不能成为科学结论。',
        'G_GOV':'治理框架关注授权、问责、利益冲突、申诉、弱势主体与不可逆后果。它必须限制 Purpose 的行动权，但不应把监管术语冒充世界本体。治理规则本身也要接受版本、外部证据和受影响者反作用。',
        'G_STUDENT':'学生和新贡献者框架关注入口是否清晰、任务是否有限、失败是否可学习。它能揭示术语和仓库结构的进入成本。为降低门槛而制作的教学简化必须标注压缩损失，不能替代完整语义束。',
        'G_PUBLIC':'公众与媒体框架关注名称的传播意义、风险想象和可理解性。它可以暴露社会接受问题，却容易把机制研究拟人化、把条件命题写成确定事实。该框架的材料应被保存为影响关系，而不是直接成为科学证据。'
    }
    for frame in mission_bundle['frames']:
        add_heading(doc,f"{frame['frame_id']} · {frame['observer']}",2)
        add_para(doc,f"情境：{frame['context']}。当前目的：{frame['purpose']}。权限角色：{frame.get('authority','participant')}。{frame_notes.get(frame['frame_id'],'该框架必须公开观察边界、证据来源和目的冲突，并接受其他框架反向修订。')}")
        add_para(doc,'与其他框架的接口至少包括：向 D 提供可追溯观察；向 I 暴露关系和依赖；向 K 提出可检验结构；向 W 表达受影响者权衡；向 P 说明授权与退出。任何一个框架都不能以“更接近本质”为由获得固定优先权。')

    add_heading(doc,'附录 E：十二类语义失败与恢复场景',1)
    failure_cards=[
        ('概念先行','先确定“人工意识操作系统”的名称，再从材料中寻找支持。','把名称放入隔离区，重新从观察者框架和根问题启动；比较无该名称时是否仍能描述同一关系。'),
        ('线性金字塔','所有数据必须向上升级为信息、知识、智慧和目的，反向变换被视为退化。','强制登记 P→D、W→I、K→D 等逆向路径，检查目的如何选择数据、知识如何要求新观测。'),
        ('Purpose 君主','把创始人愿景或模型目标写成不可修改的最高目的。','建立竞争目的、授权来源、受影响者否决、暂停与撤销；运行目的扰动。'),
        ('证据—价值偷换','模型内部存在某结构，被直接解释为有意识或应获得权利。','拆分机制关系、功能关系、体验主张和规范判断；分别列出证据与不支持。'),
        ('平均掉冲突','用加权总分把不可通约价值、哲学分歧或授权冲突变成一个数字。','保留 contested branch、obstruction、否决权和申诉，不要求全部粘合。'),
        ('新轴本体化','为解释残余提出一个新维度，随即命名成新理论和新仓库。','设置临时状态、到期日、区分实验、独立复现和回滚；无增量区分能力则退休。'),
        ('仓库词汇合并','名称相似就判断两个项目重复或应合并。','比较根问题、输入输出、证据、用户、场景、维护者和版本谱系，只触发人工审查。'),
        ('外部复现装饰','邀请外部团队运行，但失败不能修改主张或版本。','在契约中写明外部结果的修改权；至少一次失败必须形成 Schema、算子或关系变更。'),
        ('残余清洗','为形成漂亮架构图而删除不一致数据、少数框架或未知。','把残余作为一等对象；发布未闭合列表和下一轮实验，不以完整率评价质量。'),
        ('分数实体化','把稳定度、捕获风险或路由分数当成对象内在属性。','把分数绑定算法版本和任务目的；提供替代权重与敏感性分析。'),
        ('语义闭合误读','把当前任务可执行解释成概念已经被定义。','在每个契约和输出中加入 non-definition clause 与 review trigger。'),
        ('方法封闭','把 MESH² 本身当作唯一解释框架，排斥其他建模方法。','允许其他模型作为观察者框架和转换算子进入；MESH² 只要求来源、关系、残余与可修订性可见。')
    ]
    add_table(doc,['失败类型','典型表现','恢复动作'],failure_cards,widths=[3.0,6.1,7.1],font_size=7.8)
    for name,symptom,recovery in failure_cards:
        add_heading(doc,name,2)
        add_para(doc,f'典型表现：{symptom} 这种失败的危险不只在结论可能错误，更在于它改变了后续注意、数据收集、资源分配和项目诞生，形成自我强化。MESH² 要求检查该失败通过哪些 P→D、P→I、P→K 或 W→P 路径发生。')
        add_para(doc,f'恢复：{recovery} 恢复完成的证据不是一份更谨慎的声明，而是可检查的 before/after 语义束：新增了哪些观察者、哪些关系被降级、哪些残余被恢复、哪些行动被暂停、哪个外部实验可以继续区分。')

    add_heading(doc,'附录 F：发布前操作检查清单',1)
    operational_checks=[
        '所有输入是否具有 observer、context、purpose、time、scale 和 provenance？',
        '是否把引用、推断、价值、授权和传播叙事分别建模？',
        '是否存在至少一个与创始人目的不同的合法 Purpose？',
        '25 类变换是否覆盖；若未覆盖，是否记录省略理由和风险？',
        '每个关键转换是否记录 semantic_loss、residuals 和 falsifier？',
        '稳定关系是否跨越多个观察者和目的，而非同源重复表达？',
        '反对框架是否被保留，还是被总分或摘要静默删除？',
        '临时新轴是否真正增加区分能力；是否有到期与回滚？',
        '任务语义契约是否禁止无范围终局定义和形而上认证？',
        '行动边界是否区分知识支持、价值支持、授权和责任？',
        '项目门禁是否由非创始审查者复核？',
        '仓库相似性是否只触发分析，而非自动合并？',
        'source-first、测试、Release、引用与安全文件是否存在？',
        '外部失败是否具有改变关系、算子、目的或版本的权力？',
        '最终传播是否明确说明“当前输出不能证明什么”？'
    ]
    for x in operational_checks:add_bullet(doc,'□ '+x)

    add_heading(doc,'附录 G：参考资料',1)
    refs=[
        'Duan, Yucong. DIKWP-MESH² GitHub repository and README, public page observed 2026-07-18: https://github.com/YucongDuan/DIKWP-MESH-',
        'Duan, Yucong. GitHub repositories page, public profile snapshot observed 2026-07-18: https://github.com/YucongDuan?tab=repositories',
        'Kofman, K. et al. (2026). Defining Life: A Conversation. Organisms 9(1), 11–45. DOI: 10.13133/2532-5876/19492.',
        'Anthropic (2026). A Global Workspace in Language Models / Jacobian-lens related research materials. The mechanism does not by itself establish phenomenal consciousness.',
        '第四届世界人工意识大会未来发展预测与判断报告（2026）：强调成果应可引用、可复现、可执行、可持续迭代，并避免把当前 AI 主观体验作为既定事实。',
        '本交付所附 DIKWP-MESH 4.0 SemanticClosure Version Family：三无输入、主锚点、语义闭合、残余与 Kill 条件。'
    ]
    for i,r in enumerate(refs,1):add_para(doc,f'{i}. {r}',indent=False)
    add_heading(doc,'附录 H：简版发布前检查表',1)
    checks=['是否仍有句子把名称写成观察者无关的本质？','是否完整登记 25 类变换或说明省略？','Purpose 是否可修订、暂停、退出和被外部结果限制？','是否保存冲突、语义损失、无法翻译部分和反例？','临时新轴是否有区分实验与回滚条件？','项目是否 source-first、可运行、可复现？','是否有非创始审查者和受影响者代表？','是否禁止算法自动创建、删除或合并在线仓库？','是否记录版本、哈希、来源和局限？','是否把“当前任务可执行”误写成“概念已经终结”？']
    for x in checks:add_bullet(doc,'□ '+x)


def build():
    doc=Document();build_styles(doc)
    sec=doc.sections[0];sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.7);sec.left_margin=Cm(2.05);sec.right_margin=Cm(2.05)
    header=sec.header.paragraphs[0];header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    hr=header.add_run('DIKWP-MESH² ROOTS OS v1.0 · 无定义语义探究');hr.font.size=Pt(8.5);hr.font.color.rgb=RGBColor(91,110,123);set_run_font(hr)
    add_page_number(sec.footer.paragraphs[0])
    props=doc.core_properties;props.title=TITLE;props.subject=SUBTITLE;props.author='Public reference implementation contributors (to be confirmed)';props.keywords='DIKWP-MESH², no-definition, semantic inquiry, intention field, project birth gate'
    title_page(doc);nav(doc);content(doc)
    OUT.parent.mkdir(parents=True,exist_ok=True);doc.save(OUT)
    print(OUT)

if __name__=='__main__':build()

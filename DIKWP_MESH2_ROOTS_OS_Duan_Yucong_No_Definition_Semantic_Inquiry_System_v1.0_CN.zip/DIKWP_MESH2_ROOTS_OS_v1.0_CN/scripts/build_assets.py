from pathlib import Path
import json
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib import font_manager

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets'; OUT.mkdir(exist_ok=True)
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(font_path)
plt.rcParams['font.family']='Noto Sans CJK JP'
plt.rcParams['axes.unicode_minus']=False


def box(ax, x,y,w,h,text,fc='#EAF3F7',ec='#2E6173',fs=11,lw=1.5):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.02',fc=fc,ec=ec,lw=lw)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,wrap=True)
    return p

def arrow(ax,x1,y1,x2,y2,rad=0,ls='-',color='#506779'):
    a=FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=13,connectionstyle=f'arc3,rad={rad}',lw=1.35,linestyle=ls,color=color)
    ax.add_patch(a)

# Architecture
fig,ax=plt.subplots(figsize=(16,9)); ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.5,.965,'DIKWP-MESH² ROOTS OS：无定义语义本质发现与项目去概念化架构',ha='center',va='top',fontsize=20,fontweight='bold')
box(ax,.035,.69,.15,.16,'输入语义束\n观察者·情境·目的\n数据·来源·反例',fc='#EDF6F9')
box(ax,.23,.69,.15,.16,'定义隔离区\n名称降级为索引\n保留而不删除',fc='#FFF4E5',ec='#9B6B2D')
box(ax,.425,.69,.15,.16,'25 类共等变换\nDIKWP × DIKWP\n路由随目的场变化',fc='#EAF7EE',ec='#39714A')
box(ax,.62,.69,.15,.16,'语义粘合与阻碍\n稳定关系·分支\n冲突·残余·损失',fc='#F3EDFA',ec='#76509B')
box(ax,.815,.69,.15,.16,'概念逃逸\n临时新轴\n区分实验·回滚',fc='#FDEEEE',ec='#9A4F4F')
for x in [.185,.38,.575,.77]: arrow(ax,x,.77,x+.045,.77)
box(ax,.08,.38,.23,.17,'任务语义契约\n用途与竞争用途\n允许/禁止输出\n行动边界·Kill 条件',fc='#EEF4FF',ec='#425E93')
box(ax,.385,.38,.23,.17,'项目诞生门禁\n定义捕获·层级泄漏\n目的君主·残余删除\n可检验/开放/维护缺口',fc='#FFF7E8',ec='#927033')
box(ax,.69,.38,.23,.17,'仓库语义图谱\n根问题·分支·场景\n高重叠只触发审查\n不自动合并',fc='#E9F7F5',ec='#357269')
arrow(ax,.69,.69,.195,.55,rad=-.08); arrow(ax,.69,.69,.5,.55,rad=0); arrow(ax,.69,.69,.805,.55,rad=.08)
box(ax,.22,.10,.56,.17,'输出：可引用语义束，而非概念终局\nInvariant Kernel + Branches + Obstructions + Residuals + Temporary Axes + Task Contract + Human Review',fc='#DDEFF2',ec='#1E6370',fs=12)
for x in [.195,.5,.805]: arrow(ax,x,.38,.5,.27,rad=(.5-x)*.25)
ax.text(.5,.035,'核心约束：D/I/K/W/P 共等；Purpose 是分布式可修订场；任何新轴均可撤销；外部世界必须能够改变结论。',ha='center',fontsize=12,color='#334B5C')
fig.tight_layout();fig.savefig(OUT/'architecture_cn.png',dpi=180,bbox_inches='tight');plt.close(fig)

# 25 matrix
fig,ax=plt.subplots(figsize=(12,10)); ax.set_xlim(0,6);ax.set_ylim(0,6);ax.axis('off')
types=list('DIKWP')
labels={'D':'Data / 差异','I':'Information / 关系','K':'Knowledge / 结构','W':'Wisdom / 权衡','P':'Purpose / 目的'}
ax.text(3,5.82,'25 类共等 DIKWP×DIKWP 原语矩阵',ha='center',fontsize=20,fontweight='bold')
for j,t in enumerate(types):
    box(ax,1+j,.1+4.75,.9,.55,labels[t],fc='#DCECF3',fs=9)
for i,s in enumerate(types):
    y=4.45-i*.82
    box(ax,.05,y,.9,.62,labels[s],fc='#DCECF3',fs=9)
    for j,t in enumerate(types):
        code=f'T_{s}{t}'
        fc='#EAF7EE' if s!=t else '#FFF4E5'
        box(ax,1+j,y,.9,.62,code,fc=fc,ec='#557383',fs=11)
ax.text(3,.26,'行与列均为语义资源角色，不表示等级；线性 D→I→K→W→P 只是 25 类中的一条路线。',ha='center',fontsize=11)
fig.tight_layout();fig.savefig(OUT/'matrix_25_cn.png',dpi=180,bbox_inches='tight');plt.close(fig)

# Correction loop
fig,ax=plt.subplots(figsize=(15,8));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.5,.95,'从概念定义循环调整为 DIKWP-MESH² 语义探究循环',ha='center',fontsize=19,fontweight='bold')
steps=[
('名称/直觉\n仅作入口',.04,'#F1F5F8'),('观察者框架\nO·C·P·T·S',.19,'#E9F4FB'),('语义原子\nD/I/K/W/P',.34,'#EAF7EE'),('25 类变换\n多路径往返',.49,'#FFF4E5'),('关系与阻碍\n不强行统一',.64,'#F3EDFA'),('实验/行动\n外部反作用',.79,'#FDEEEE')]
for text,x,fc in steps: box(ax,x,.58,.13,.18,text,fc=fc,fs=11)
for i in range(len(steps)-1):arrow(ax,steps[i][1]+.13,.67,steps[i+1][1],.67)
box(ax,.13,.22,.22,.17,'若出现定义捕获\n降级为框架投影\n补反例与残余',fc='#FFE8E8',ec='#9A4F4F')
box(ax,.40,.22,.22,.17,'若现有轴不足\n提出临时新轴\n设计区分实验',fc='#FFF4E5',ec='#9B6B2D')
box(ax,.67,.22,.22,.17,'若外部结果改变\n修订关系/目的/算子\n保留版本谱系',fc='#E7F4EE',ec='#39714A')
arrow(ax,.855,.58,.78,.39,rad=.1);arrow(ax,.67,.30,.62,.30);arrow(ax,.40,.30,.35,.30);arrow(ax,.13,.30,.105,.58,rad=-.12)
ax.text(.5,.08,'停止条件：输出不再被命名概念支配，而能明确说明当前任务下较稳定的关系、保留分支、不可粘合阻碍和下一步区分行动。',ha='center',fontsize=11.5)
fig.tight_layout();fig.savefig(OUT/'correction_loop_cn.png',dpi=180,bbox_inches='tight');plt.close(fig)

# Repo semantic families
atlas=json.loads((ROOT/'outputs/demo/repo_semantic_atlas.json').read_text(encoding='utf-8'))
fig,ax=plt.subplots(figsize=(14,9));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.5,.96,'段玉聪 GitHub：名称不是本体，仓库是根问题的观察者—目的分支',ha='center',fontsize=19,fontweight='bold')
center=Circle((.5,.52),.105,fc='#DDEFF2',ec='#1E6370',lw=2);ax.add_patch(center);ax.text(.5,.52,'共享根问题\n如何把不完整、冲突、\n观察者依赖的语义\n转化为可审计行动？',ha='center',va='center',fontsize=10,fontweight='bold')
positions=[(.16,.75),(.50,.82),(.83,.75),(.85,.38),(.61,.17),(.30,.17),(.14,.38),(.50,.36)]
for (fam,x),pos in zip([(f['family'],f['count']) for f in atlas['families']],positions):
    label=f'{fam}\n{x} 个代表仓库'
    box(ax,pos[0]-.095,pos[1]-.06,.19,.12,label,fc='#F2F5F7',fs=9)
    arrow(ax,.5,.52,pos[0],pos[1],rad=.05 if pos[0]>.5 else -.05,color='#718696')
ax.text(.5,.045,'高重叠名称只触发交叉分析：比较问题、证据、受影响者、目的和维护边界；不得仅凭词汇相似自动合并。',ha='center',fontsize=11)
fig.tight_layout();fig.savefig(OUT/'repo_semantic_families_cn.png',dpi=180,bbox_inches='tight');plt.close(fig)

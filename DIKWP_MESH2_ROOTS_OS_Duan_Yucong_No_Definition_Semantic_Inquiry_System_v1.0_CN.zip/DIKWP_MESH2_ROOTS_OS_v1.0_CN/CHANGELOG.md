# Changelog

## 1.0.0 - 2026-07-18

- Added all 25 co-equal DIKWP×DIKWP primitive transformations.
- Added no-definition quarantine and observer/context/purpose indexing.
- Added distributed purpose-field routing.
- Added invariant, branch, obstruction and temporary-axis outputs.
- Added task semantic contracts and project-birth gate.
- Added representative GitHub semantic atlas.
- Added offline dashboard, schemas and deterministic tests.
